package MBIPV.utils;

public class DataPermission  {
	private Data data; 
	private String grantToEntity; 

	public Data getData() {
		return data;
	}
	public void setData(Data data) {
		this.data = data;
	}
	public String getGrantToEntity() {
		return grantToEntity;
	}
	public void setGrantToEntity(String grantToEntity) {
		this.grantToEntity = grantToEntity;
	}	
}