package MBIPV.handlers;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import MBIPV.utils.Data;
import MBIPV.utils.Process;
import MBIPV.utils.DataAccess;
import MBIPV.utils.DataFlow;
import MBIPV.utils.DataStore;
import MBIPV.utils.DataTransmissionConfig;
import MBIPV.utils.Entity;
import MBIPV.utils.EntityProcess;
import MBIPV.utils.GetElementByID;
import MBIPV.utils.GetElementsByDependency;
import MBIPV.utils.GetElementsBySupplier;
import MBIPV.utils.GetEntityByProcess;
import MBIPV.utils.UMLModel;



public class GetUMLModel {
	public static UMLModel main(String dataAccessFileName, List<String> dataFileNameList, List<String> dataFlowFileNameList) throws DocumentException{
	   
	   UMLModel model = new UMLModel();			   
	  
	   //Get the data access list from the UML model AccessToData.
	   File dataAccessFile = new File(dataAccessFileName);
	   SAXReader saxDataAccess = new SAXReader();
	   Document documentDataAccess = saxDataAccess.read(dataAccessFile);
	   Element rootDataAccess = documentDataAccess.getRootElement();
	   List<DataAccess> dataAccessList = new ArrayList<DataAccess>();
	   dataAccessList = getDataAccessList(dataAccessList, rootDataAccess, dataAccessFileName);
	   model.setDataAccessList(dataAccessList);
	   
	   //Get the list of data from the UML model Data.
	   List<Data> dataList = new ArrayList<Data>();
	   if(dataFileNameList != null && dataFileNameList.size()>0) {
		   for(String dataFileName:dataFileNameList) {
			   File dataFile = new File(dataFileName);
			   SAXReader saxData = new SAXReader();
			   Document documentData = saxData.read(dataFile);
			   Element rootData = documentData.getRootElement();
			   dataList = getDataList(dataList, rootData, dataFileName);				   
		   }
	   }
	   model.setDataList(dataList);	     
	   
	   //Get the list of entities from the UML model DataFlow.
	   List<Entity> entityList = new ArrayList<Entity>();
	   if(dataFlowFileNameList != null && dataFlowFileNameList.size()>0) {
		   for(String fileName:dataFlowFileNameList) {
			   File xmlFile = new File(fileName);
	    	   SAXReader sax = new SAXReader();
	    	   Document document = sax.read(xmlFile);
	    	   Element root = document.getRootElement();
	    	   Entity entity = new Entity();
	    	   entity = getEntity(entity, dataList, root, fileName);
	    	   entityList.add(entity);
		   }
	   }
	   model.setEntityList(entityList);
	   
	   //Set the name of the model.
	   String separator = File.separator;
	   String[] s = dataAccessFileName.split("\\" + separator);
//	   System.out.println("MBIPV.handlers.GetUMLModel.main-----dataAccessFileName:"+dataAccessFileName);
	   if(s!=null && s.length>0) {
		   for(int i = 0;i<s.length;i++)
//		   System.out.println("MBIPV.handlers.GetUMLModel.main-----s[i]:"+s[i]);
		   model.setName(s[s.length-2]);
		   System.out.println("MBIPV.handlers.GetUMLModel.main-----s[s.length-2](model name):"+s[s.length-2]);

	   }
	   
	   //Output entities in the UML models.
	   if(model!=null) {
		   entityList = model.getEntityList();
		   if(entityList!=null && entityList.size()>0) {
	   		   for(Entity entity:entityList) {
	   			   System.out.println("GetUMLModel EntityList Entity Name:"+ entity.getEntityName()) ;
	   			   if(entity.getProcessList()!=null && entity.getProcessList().size()>0) {
	   				   for(Process process:entity.getProcessList()) {
			   			   System.out.println("		process name:" + process.getName() );
	   					   List<DataFlow> dataFlowIn = process.getDataFlowInList();
	   					   if(dataFlowIn!=null && dataFlowIn.size()>0) {
	   						   for(DataFlow in : dataFlowIn) {
	   				   			   System.out.println("			dataFlowIn sourceEntity:" + in.getSource_entity_process().getEntity());
	   				   			   System.out.println("			dataFlowIn sourceProcess:" + in.getSource_entity_process().getProcess());
	   				   			   System.out.println("			dataFlowIn targetEntity:" + in.getTarget_entity_process().getEntity());
	   				   			   System.out.println("			dataFlowIn targetProcess:" + in.getTarget_entity_process().getProcess());
	   							   DataTransmissionConfig config = in.getData_transmission_config();
	   							   if(config != null) {
		   				   			   System.out.println("			config:" + config.getCipherType());
		   				   			   System.out.println("			config:" + config.getHashingType());
		   				   			   System.out.println("			config:" + config.getNetType());
		   				   			   System.out.println("			config:" + config.getProtocolType());
		   				   			   System.out.println("			config:" + config.getPwdType());
		   				   			   System.out.println("			config:" + config.getSigType());
		   				   			   List<Data> data = config.getData();
		   				   			   if(data!=null && data.size()>0) {
		   				   				   for(Data d:data)
		   				   					   if(d!=null)
		   				   						   System.out.println("				data:" +d.getDataName());
		   				   			   }
		   				   			   else {
			   				   			   System.out.println("			Error: data is null!");		   				   				   
		   				   			   }
	   							   }
	   							   else
		   				   			   System.out.println("			Error: config is null!");
	   								   
	   						   }
	   					   }
	   				   }
	   				   
	   			   }
			   }
		   }  
		   dataList = model.getDataList();
		   if(dataList!=null && dataList.size()>0) {
			   for(Data data:dataList) {
				   System.out.println("		 data:" + data.getDataName() + " entity:" + data.getEntity() + " from external entity:" + data.getFromExternalEntity() + " is privacy:" + data.getIsPrivacy() + "dependsOn:" + data.getDependsOnData());
			   }
		   }
		   dataAccessList = model.getDataAccessList();
		   if(dataAccessList!=null && dataAccessList.size()>0) {
			   for(DataAccess dataAccess:dataAccessList) {
				   System.out.println("	    	dataAccess:" + dataAccess.getEntityProcess().getEntity() + " " + dataAccess.getEntityProcess().getProcess() + " " + dataAccess.getType() + " " + dataAccess.getData());
			   }
		   }
	   }
	return model;
	}

	public static List<Data> getDataList(List<Data> dataList, Element node, String fileName) throws DocumentException {
		//Recursively read all the model elements in the UML file of the Data model.
		if(node.getName().equals("packagedElement")) {
			String packagedElementID = node.attributeValue("id");
//			System.out.println("MBIPV.handlers.GetUMLModel.getDataList:  packagedElementID:" + packagedElementID);			    
			Element basedStereotype = GetElementByID.getElement(packagedElementID, fileName, "base_NamedElement");
			if(basedStereotype!=null) {
//				System.out.println("MBIPV.handlers.GetUMLModel.getDataList:  name:" + basedStereotype.getName());			    				
			}
			if(basedStereotype!=null && basedStereotype.getName().equals("Entity")) {
			    String entityName = node.attributeValue("name");
//				System.out.println("MBIPV.handlers.GetUMLModel.getDataList:  entityName:" + entityName);			    
			    List<Element> listElement = node.elements();
			    for (Element e : listElement) {
					List<Attribute> attrList = e.attributes();
					if(attrList!=null && attrList.size()>0) {
						for(Attribute attribute:attrList) {
							if(attribute.getName().equals("type") && !attribute.getValue().contains(":")) {
								String dataElementID = attribute.getValue();
//								System.out.println("MBIPV.handlers.GetUMLModel.getDataList:   fileName:" + fileName + " dataElementID:" + dataElementID);
								Element dataElement = GetElementByID.getElement(dataElementID, fileName, "id");
								String dataName = dataElement.attributeValue("name");
								Element dataStereotype = GetElementByID.getElement(dataElementID, fileName, "base_Class");
								String isPrivacy = dataStereotype.attributeValue("isPrivacy");
								String fromEnternalEntity = dataStereotype.attributeValue("fromEnternalEntity");
								Element dataDependsOnElement = GetElementByID.getElement(dataElementID, fileName, "client");
								String dependsOnData = "";
								if(dataDependsOnElement!=null) {
									String supplierID = dataDependsOnElement.attributeValue("supplier");
									Element supplierElement = GetElementByID.getElement(supplierID, fileName, "id");
									dependsOnData= supplierElement.attributeValue("name");
								}
								Data data = new Data();
								data.setDataName(dataName);
								data.setEntity(entityName);
								data.setIsPrivacy(isPrivacy);
								data.setFromExternalEntity(fromEnternalEntity);	
								data.setDependsOnData(dependsOnData);
								dataList.add(data);
							}
						}
					}
			    }
			}
			}

	// Recursively iterate through all the child nodes of the current node.
    List<Element> elementList = node.elements();
    for (Element e : elementList) {
    	dataList = getDataList(dataList,e,fileName);
    }
	return dataList;   
	}	
	
	private static List<DataAccess> getDataAccessList(List<DataAccess> dataAccessList, Element node,String fileName) throws DocumentException {
		//Recursively read all the model elements in the UML file of the AccessToData model.
    	String nodeName = node.getName();
	    if(nodeName!=null && nodeName.equals("dataAccess")) {
	    	String baseUseCaseID = node.attributeValue("base_UseCase");
	    	Element useCaseElement = GetElementByID.getElement(baseUseCaseID, fileName, "id");
	    	String useCaseName = useCaseElement.attributeValue("name");//The name is "AccessToXXX".
	    	String dataName = useCaseName.split("AccessTo")[1];
//	    	System.out.println("MBIPV.handlers.GetUMLModel.getDataAccessList---dataName:" + dataName + " useCaseName:" + useCaseName);
	    	List<Element> dependencyElementList = GetElementsBySupplier.getElement(baseUseCaseID, fileName);
	    	if(dependencyElementList != null && dependencyElementList.size() > 0) {
	    		for(Element dependencyElement:dependencyElementList) {
    				DataAccess dataAccess = new DataAccess();
    				dataAccess.setData(dataName);
    				
	    			String processElementID = dependencyElement.attributeValue("client");//The process related to the data.
//	    	    	System.out.println("MBIPV.handlers.GetUMLModel.getDataAccessList---processElementID:" + processElementID);
	    			Element processElement = GetElementByID.getElement(processElementID, fileName, "id");
	    			String processName = processElement.attributeValue("name");
	    	    	System.out.println("MBIPV.handlers.GetUMLModel.getDataAccessList---processName:" + processName);
	    			Element entityEnd = GetEntityByProcess.getElement(processElementID, fileName);
	    			List<Attribute> entityEndAttrList = entityEnd.attributes();
	    			String entityElementID = "";
	    			if(entityEndAttrList!=null && entityEndAttrList.size()>0) {
	    				for(Attribute attr:entityEndAttrList) {
	    					String attrName = attr.getName();
	    					String attrValue = attr.getValue();
	    					if(attrName.equals("type") && !attrValue.equals("uml:Property")) {
	    						entityElementID = attrValue; 
	    					}
	    				}
	    			}
	    			Element entityElement = GetElementByID.getElement(entityElementID, fileName, "id");
	    			String entityName = entityElement.attributeValue("name");
	    	    	EntityProcess entityProcess = new EntityProcess();//The entity's process which grants, revokes or requests access to data.
	    	    	entityProcess.setEntity(entityName);
	    	    	entityProcess.setProcess(processName);
    				dataAccess.setEntityProcess(entityProcess);

	    			String dependencyID = dependencyElement.attributeValue("id");
	    			List<Element> stereotypeElements = GetElementsByDependency.getElement(dependencyID, fileName);
	    			if(stereotypeElements != null && stereotypeElements.size() > 0) {
	    				for(Element stereotypeElement:stereotypeElements) {
	    					String sterotypeName = stereotypeElement.getName();//"grants","revokes" or "requests"		
	    					DataAccess newDataAccess = new DataAccess();
	    					newDataAccess.setData(dataName);
	    					newDataAccess.setEntityProcess(entityProcess);
	    					newDataAccess.setType(sterotypeName);
	    					dataAccessList.add(newDataAccess);
	    				}
	    			}
	    		}
	    	}
	    }
		// Recursively iterate through all the child nodes of the current node.
	    List<Element> listElement = node.elements();
	    for (Element e : listElement) {
	    	dataAccessList = getDataAccessList(dataAccessList,e,fileName);
	    }
		return dataAccessList;   
	}
	private static Entity getEntity(Entity entity, List<Data> dataList, Element node,String fileName) throws DocumentException {
		//Recursively read all the model elements in the UML file of the DataFlow model.
		if(node.getName().equals("packagedElement")) {
			String entityName = node.attributeValue("name");
//			System.out.println("Entity getEntity:" + entityName);
		    List<Element> listElement = node.elements();//Child elements of the node.
		    
			List<Data> entityDataList = new ArrayList<Data>();
			List<Data> externalDataList = new ArrayList<Data>();
			List<DataStore> dataStoreList = new ArrayList<DataStore>();
			List<Process> processList = new ArrayList<Process>();
			
			//Set dataList and external dataList.
			if(dataList!=null && dataList.size()>0) {
				for(Data data:dataList) {
					if(data.getEntity().equals(entityName)) {
						String isExternal = data.getFromExternalEntity();
						if(isExternal.equals("true")) {
							externalDataList.add(data);
						}
						else {
							entityDataList.add(data);
						}
					}
				}
			}

			//Set dataStoreList.		
		    if(listElement!=null && listElement.size()>0) {
		    	for(Element e:listElement) {
		    		if(e.attributeValue("type")!=null && e.attributeValue("type").equals("uml:DataStoreNode")) {
		    			DataStore dataStore = new DataStore();
		    			//Initialize dataFlowIn and dataFlowOut lists of each dataStore.
		    			List<DataFlow> dataFlowInList = new ArrayList<DataFlow>();
		    			List<DataFlow> dataFlowOutList = new ArrayList<DataFlow>();
		    			
		    			String dataStoreName = e.attributeValue("name");
		    			
		    			//Get ID of the incoming and outgoing data flow elements.
		    			String incomingFLowElementIDList = e.attributeValue("incoming");
		    			String outgoingFlowElementIDList = e.attributeValue("outgoing");
		    			//Incoming data flow.
		    			if(incomingFLowElementIDList != null) {
		    				if(incomingFLowElementIDList.contains(" ")) {
			    				//There is more than one incoming data flow.
			    				for(String incomingFLowElementID:incomingFLowElementIDList.split(" ")) {
					    			Element incomingFlow = GetElementByID.getElement(incomingFLowElementID, fileName, "id");
					    			DataFlow dataFlowIn = setDataFLowByUMLElementForDataStore(incomingFlow, fileName, entityName, dataStoreName, dataList, "source");
					    			dataFlowInList.add(dataFlowIn);
			    				}
			    			}
			    			else {
			    				//Only one incoming data flow.
				    			Element incomingFlow = GetElementByID.getElement(incomingFLowElementIDList, fileName, "id");
				    			DataFlow dataFlowIn = setDataFLowByUMLElementForDataStore(incomingFlow, fileName, entityName, dataStoreName, dataList, "source");
				    			dataFlowInList.add(dataFlowIn);		    				
			    			}
		    			}
		    			//Outgoing data flow.
		    			if(outgoingFlowElementIDList != null) {
		    				if(outgoingFlowElementIDList.contains(" ")) {
			    				//There is more than one outgoing data flow.
			    				for(String outgoingFLowElementID:outgoingFlowElementIDList.split(" ")) {
					    			Element outgoingFlow = GetElementByID.getElement(outgoingFLowElementID, fileName, "id");
					    			DataFlow dataFlowOut = setDataFLowByUMLElementForDataStore(outgoingFlow, fileName, entityName, dataStoreName, dataList, "target");
					    			dataFlowOutList.add(dataFlowOut);
			    				}
			    			}
			    			else {
			    				//Only one outgoing data flow.
				    			Element outgoingFlow = GetElementByID.getElement(outgoingFlowElementIDList, fileName, "id");
				    			DataFlow dataFlowOut = setDataFLowByUMLElementForDataStore(outgoingFlow, fileName, entityName, dataStoreName, dataList, "target");
				    			dataFlowOutList.add(dataFlowOut);		    				
			    			}
		    			}		
		    			//Set information for the dataStore.
		    			dataStore.setName(dataStoreName);
		    			dataStore.setEntity(entityName);
		    			dataStore.setDataFlowInList(dataFlowInList);
		    			dataStore.setDataFlowOutList(dataFlowOutList);
		    			//Add the dataStore to the dataStoreList.
		    			dataStoreList.add(dataStore);
		    		}
		    	}
		    }
		    //Set processList.
		    if(listElement!=null && listElement.size()>0) {
		    	for(Element e:listElement) {
		    		if(e.attributeValue("type")!=null && e.attributeValue("type").equals("uml:CallBehaviorAction") && GetElementByID.getElement(e.attributeValue("id"), fileName, "base_CallBehaviorAction").getName().equals("CallProcess")) {
		    			//Init dataFlowIn and dataFlowOut lists of each process.
		    			List<DataFlow> dataFlowInList = new ArrayList<DataFlow>();
		    			List<DataFlow> dataFlowOutList = new ArrayList<DataFlow>();
		    			
		    			String processName = e.attributeValue("name");
//		    			System.out.println("MBIPV.handlers.GetUMLModel.getEntity---processName:" + processName);
		    			//Get ID of the incoming and outgoing data flow elements.
		    			List<Element> subElements = e.elements();
		    			if(subElements!=null && subElements.size()>0) {
		    				for(Element subElement:subElements) {
				    			String incomingFLowElementIDList = subElement.attributeValue("incoming");
				    			String outgoingFlowElementIDList = subElement.attributeValue("outgoing");	
				    			//Incoming data flow.
				    			if(incomingFLowElementIDList != null) {
					    			if(incomingFLowElementIDList.contains(" ")) {
					    				//There is more than one incoming data flow.
					    				for(String incomingFLowElementID:incomingFLowElementIDList.split(" ")) {
							    			Element incomingFlow = GetElementByID.getElement(incomingFLowElementID, fileName, "id");
							    			List<DataFlow> dataFlowIn = setDataFLowByUMLElementForProcess(incomingFlow, fileName, entityName, processName, dataList, dataStoreList, "source");
							    			if(dataFlowIn != null && dataFlowIn.size()>0)
							    				dataFlowInList.addAll(dataFlowIn);
					    				}
					    			}
					    			else {
					    				//Only one incoming data flow.
						    			Element incomingFlow = GetElementByID.getElement(incomingFLowElementIDList, fileName, "id");
						    			List<DataFlow> dataFlowIn = setDataFLowByUMLElementForProcess(incomingFlow, fileName, entityName, processName, dataList, dataStoreList, "source");
						    			if(dataFlowIn != null && dataFlowIn.size()>0)
						    				dataFlowInList.addAll(dataFlowIn);		    				
					    			}
				    			}
				    			//Outgoing data flow.
				    			if(outgoingFlowElementIDList != null) {
					    			if(outgoingFlowElementIDList.contains(" ")) {
					    				//There is more than one outgoing data flow.
					    				for(String outgoingFLowElementID:outgoingFlowElementIDList.split(" ")) {
							    			Element outgoingFlow = GetElementByID.getElement(outgoingFLowElementID, fileName, "id");
							    			List<DataFlow> dataFlowOut = setDataFLowByUMLElementForProcess(outgoingFlow, fileName, entityName, processName, dataList, dataStoreList, "target");
							    			if(dataFlowOut != null && dataFlowOut.size()>0)
							    				dataFlowOutList.addAll(dataFlowOut);
					    				}
					    			}
					    			else {
					    				//Only one outgoing data flow.
						    			Element outgoingFlow = GetElementByID.getElement(outgoingFlowElementIDList, fileName, "id");
						    			List<DataFlow> dataFlowOut = setDataFLowByUMLElementForProcess(outgoingFlow, fileName, entityName, processName, dataList, dataStoreList, "target");
						    			if(dataFlowOut != null && dataFlowOut.size()>0)
						    				dataFlowOutList.addAll(dataFlowOut);		    				
					    			}	
				    			}
		    				}
		    			}
		    			Process process = new Process();
		    			//Set information for the process.
		    			process.setEntity(entityName);
		    			process.setDataFlowInList(dataFlowInList);
		    			process.setDataFlowOutList(dataFlowOutList);
		    			process.setName(processName);
		    			//Add the process to the processList.
		    			processList.add(process);
		    		}
		    	}
		    }
		    entity.setDataList(dataList);
		    entity.setDataStoreList(dataStoreList);
		    entity.setEntityName(entityName);
		    entity.setExternalDataList(externalDataList);
		    entity.setProcessList(processList);
		}
		// Recursively iterate through all the child nodes of the current node.
	    List<Element> listElement = node.elements();
	    for (Element e : listElement) {
	    	entity = getEntity(entity, dataList, e, fileName);
	    }	
		return entity;	
	}
	private static DataFlow setDataFLowByUMLElementForDataStore(Element dataFlowElement, String fileName, String thisEntityName, String thisDataStoreName, List<Data> dataList, String type) throws DocumentException {
		//Set data flow for dataStore.
		String elementID = dataFlowElement.attributeValue(type);//Type = "source" or "target". 
//		System.out.println("GetUMLModel--setDataFLowByUMLElementForDataStore--elementID:" + elementID);
		Element connectedElement = GetElementByID.getElement(elementID, fileName, "id");
		if(connectedElement.attributeValue("name") == null) {
			//The connected element is the OutputPin of a process.
			connectedElement = connectedElement.getParent();
			elementID = connectedElement.attributeValue("id");
		}
		String connectedElementName = connectedElement.attributeValue("name");
//		System.out.println("GetUMLModel--setDataFLowByUMLElementForDataStore--connectedElementName:" + connectedElementName);		
		//The source and target of the data flow
		String sourceEntity = "";
		String sourceProcess = "";
		String targetEntity = "";
		String targetProcess = "";
//		System.out.println("GetUMLModel--setDataFLowByUMLElementForDataStore--elementID:" + elementID);				
		Element stereotypeElementExternalEntity = GetElementByID.getElement(elementID, fileName, "base_ActivityParameterNode"); 
		if(stereotypeElementExternalEntity != null && stereotypeElementExternalEntity.getName().equals("ExternalEntity")) {
//			System.out.println("GetUMLModel--setDataFLowByUMLElementForDataStore--isExternalEntity.");
			//The data is from or flows to an external entity.
			if(type.equals("source")) {
				sourceEntity = connectedElementName;
				sourceProcess = "";
				targetEntity = thisEntityName;
				targetProcess = thisDataStoreName;//DataStore is not a process, but is saved here for convenience.	
				
			}
			if(type.equals("target")) {
				sourceEntity = thisEntityName;
				sourceProcess = thisDataStoreName;//DataStore is not a process, but is saved here for convenience.	
				targetEntity = connectedElementName;
				targetProcess = "";				
			}
//			System.out.println("GetUMLModel--setDataFLowByUMLElementForDataStore--isExternalEntity sourceEntity:" + sourceEntity);
//			System.out.println("GetUMLModel--setDataFLowByUMLElementForDataStore--isExternalEntity sourceProcess:" + sourceProcess);
//			System.out.println("GetUMLModel--setDataFLowByUMLElementForDataStore--isExternalEntity targetEntity:" + targetEntity);
//			System.out.println("GetUMLModel--setDataFLowByUMLElementForDataStore--isExternalEntity sourceEntity:" + targetProcess);
			
		}
		Element stereotypeElementProcess = GetElementByID.getElement(elementID, fileName, "base_CallBehaviorAction"); 
		if(stereotypeElementProcess != null && stereotypeElementProcess.getName().equals("CallProcess")) {
			//The data is from or flows to a process of this entity.
			if(type.equals("source")) {
				sourceEntity = thisEntityName;
				sourceProcess = connectedElementName;
				targetEntity = thisEntityName;
				targetProcess = thisDataStoreName;//DataStore is not a process, but is saved here for convenience.	
			}
			if(type.equals("target")) {
				sourceEntity = thisEntityName;
				sourceProcess = thisDataStoreName;//DataStore is not a process, but is saved here for convenience.
				targetEntity = thisEntityName;
				targetProcess = connectedElementName;
			}
//			System.out.println("GetUMLModel--setDataFLowByUMLElementForDataStore--isEntityProcess sourceEntity:" + sourceEntity);
//			System.out.println("GetUMLModel--setDataFLowByUMLElementForDataStore--isEntityProcess sourceProcess:" + sourceProcess);
//			System.out.println("GetUMLModel--setDataFLowByUMLElementForDataStore--isEntityProcess targetEntity:" + targetEntity);
//			System.out.println("GetUMLModel--setDataFLowByUMLElementForDataStore--isEntityProcess sourceEntity:" + targetProcess);
		}
		
		DataTransmissionConfig dataTransmissionConfig = new DataTransmissionConfig(); 
		List<Data> transData = new ArrayList<Data>();
		String dataFlowElementID = dataFlowElement.attributeValue("id");
		Element stereotypeElementDataFlow = GetElementByID.getElement(dataFlowElementID, fileName, "base_ControlFlow");
		if(stereotypeElementDataFlow != null && stereotypeElementDataFlow.getName().equals("DataTransmissionConfig")) {
			//Get the data transmission configuration from the UML model.
			List<Element> elementList = stereotypeElementDataFlow.elements();
			if(elementList!=null && elementList.size()>0) {
				for(Element el:elementList) {
					if(el.getName().equals("Data")) {
						String dataName = el.getTextTrim();
						Data data = getDataByNameFromDataList(thisEntityName, dataName, dataList);		
//						System.out.println("GetUMLModel--setDataFLowByUMLElementForDataStore--dataName:" + data.getDataName());
						transData.add(data);
					}
				}
			}
    		dataTransmissionConfig.setData(transData);
			List<Attribute> attrList = stereotypeElementDataFlow.attributes();
			if(attrList!=null && attrList.size()>0) {
				for(Attribute attribute:attrList) {
//					System.out.println("GetUMLModel--setDataFLowByUMLElementForDataStore--attribute:" + attribute.getName() + " " + attribute.getValue());
					if(attribute.getName().equals("NetType")) {
						dataTransmissionConfig.setNetType(attribute.getValue());
					}
					if(attribute.getName().equals("ProtocolType")) {
						dataTransmissionConfig.setProtocolType(attribute.getValue());
					}
					if(attribute.getName().equals("PwdType")) {
						dataTransmissionConfig.setPwdType(attribute.getValue());
					}
					if(attribute.getName().equals("CipherType")) {
						dataTransmissionConfig.setCipherType(attribute.getValue());
					}
					if(attribute.getName().equals("SigType")) {
						dataTransmissionConfig.setSigType(attribute.getValue());
					}
					if(attribute.getName().equals("HashingType")) {
						dataTransmissionConfig.setHashingType(attribute.getValue());
					}
				}
			}
		}
		
		DataFlow dataFlow = new DataFlow();
		dataFlow.setData_transmission_config(dataTransmissionConfig);
		EntityProcess sourceEntityProcess = new EntityProcess();
		sourceEntityProcess.setEntity(sourceEntity);
		sourceEntityProcess.setProcess(sourceProcess);
		dataFlow.setSource_entity_process(sourceEntityProcess);
		EntityProcess targetEntityProcess = new EntityProcess();
		targetEntityProcess.setEntity(targetEntity);
		targetEntityProcess.setProcess(targetProcess);		    		
		dataFlow.setTarget_entity_process(targetEntityProcess);
		return dataFlow;
	}
	private static List<DataFlow> setDataFLowByUMLElementForProcess(Element dataFlowElement, String fileName, String thisEntityName, String thisProcessName, List<Data> dataList, List<DataStore> dataStoreList, String type) throws DocumentException {
		//Set data flow for process.
//		System.out.println("GetUMLModel--setDataFLowByUMLElementForProcess--:" + thisEntityName + " " + thisProcessName);
		String elementID = dataFlowElement.attributeValue(type);//Type = "source" or "target". 
//		System.out.println("GetUMLModel--setDataFLowByUMLElementForProcess--elementID:" + elementID);
		Element connectedElement = GetElementByID.getElement(elementID, fileName, "id");
		if(connectedElement.attributeValue("name") == null) {
			//The connected element is the OutputPin of a process.
			connectedElement = connectedElement.getParent();
			elementID = connectedElement.attributeValue("id");
//			System.out.println("GetUMLModel--setDataFLowByUMLElementForProcess--connectedElementElementID:" + elementID);
		}
		String connectedElementName = connectedElement.attributeValue("name");
//		System.out.println("GetUMLModel--setDataFLowByUMLElementForProcess--connectedElement:" + connectedElementName);
		//The source and target of the data flow
		String sourceEntity = "";
		String sourceProcess = "";
		String targetEntity = "";
		String targetProcess = "";
		
		DataTransmissionConfig dataTransmissionConfig = new DataTransmissionConfig(); 
		List<Data> transData = new ArrayList<Data>();
		String dataFlowElementID = dataFlowElement.attributeValue("id");
		Element stereotypeElementDataFlow = GetElementByID.getElement(dataFlowElementID, fileName, "base_ControlFlow");
		if(stereotypeElementDataFlow != null && stereotypeElementDataFlow.getName().equals("DataTransmissionConfig")) {
			//Get the data transmission configuration from the UML model.
			List<Element> elementList = stereotypeElementDataFlow.elements();
			if(elementList!=null && elementList.size()>0) {
				for(Element el:elementList) {
					if(el.getName().equals("Data")) {
						String dataName = el.getTextTrim();
						Data data = getDataByNameFromDataList(thisEntityName, dataName, dataList);
						transData.add(data);
						System.out.println("Data: " + dataName);
//						System.out.println("transData: " + data.getDataName());
					}
				}
			}
    		dataTransmissionConfig.setData(transData);
			List<Attribute> attrList = stereotypeElementDataFlow.attributes();
			if(attrList!=null && attrList.size()>0) {
				for(Attribute attribute:attrList) {
//					System.out.println("GetUMLModel--setDataFLowByUMLElementForProcess--attribute:" + attribute.getName() + " " + attribute.getValue());
					if(attribute.getName().equals("NetType")) {
						dataTransmissionConfig.setNetType(attribute.getValue());
					}
					if(attribute.getName().equals("ProtocolType")) {
						dataTransmissionConfig.setProtocolType(attribute.getValue());
					}
					if(attribute.getName().equals("PwdType")) {
						dataTransmissionConfig.setPwdType(attribute.getValue());
					}
					if(attribute.getName().equals("CipherType")) {
						dataTransmissionConfig.setCipherType(attribute.getValue());
					}
					if(attribute.getName().equals("SigType")) {
						dataTransmissionConfig.setSigType(attribute.getValue());
					}
					if(attribute.getName().equals("HashingType")) {
						dataTransmissionConfig.setHashingType(attribute.getValue());
					}
				}
			}
		}
		
		Element stereotypeElementExternalEntity = GetElementByID.getElement(elementID, fileName, "base_ActivityParameterNode"); 
		if(stereotypeElementExternalEntity != null && stereotypeElementExternalEntity.getName().equals("ExternalEntity")) {
			//The data is from or flows to an external entity.
			if(type.equals("source")) {
				sourceEntity = connectedElementName;
				sourceProcess = "";
				targetEntity = thisEntityName;
				targetProcess = thisProcessName;
				
			}
			if(type.equals("target")) {
				sourceEntity = thisEntityName;
				sourceProcess = thisProcessName;
				targetEntity = connectedElementName;
				targetProcess = "";				
			}
		}
		Element stereotypeElementProcess = GetElementByID.getElement(elementID, fileName, "base_CallBehaviorAction"); 
		if(stereotypeElementProcess != null && stereotypeElementProcess.getName().equals("CallProcess")) {
			//The data is from or flows to a process of this entity.
			if(type.equals("source")) {
				sourceEntity = thisEntityName;
				sourceProcess = connectedElementName;
				targetEntity = thisEntityName;
				targetProcess = thisProcessName;
			}
			if(type.equals("target")) {
				sourceEntity = thisEntityName;
				sourceProcess = thisProcessName;
				targetEntity = thisEntityName;
				targetProcess = connectedElementName;
			}
		}
		DataFlow dataFlow = new DataFlow();
		dataFlow.setData_transmission_config(dataTransmissionConfig);
		EntityProcess sourceEntityProcess = new EntityProcess();
		sourceEntityProcess.setEntity(sourceEntity);
		sourceEntityProcess.setProcess(sourceProcess);
		dataFlow.setSource_entity_process(sourceEntityProcess);
		EntityProcess targetEntityProcess = new EntityProcess();
		targetEntityProcess.setEntity(targetEntity);
		targetEntityProcess.setProcess(targetProcess);		    		
		dataFlow.setTarget_entity_process(targetEntityProcess);
		
		Element stereotypeElementDataStore = GetElementByID.getElement(elementID, fileName, "base_DataStoreNode"); 
		List<DataFlow> newDataFlowInList = null;
		List<DataFlow> newDataFlowOutList = null;
		if(stereotypeElementDataStore != null && stereotypeElementDataStore.getName().equals("DataStore")) {
			//The data is from or flows to a dataStore of this entity.
			//The dataStore's data need to be processed by the process.
			//If the source node or target node of the data flow is dataStore, continue to find the next process node connected to the dataStore.
//			System.out.println("GetUMLModel--setDataFLowByUMLElementForProcess:connectedToDataStore");
			EntityProcess thisEntityProcess =  new EntityProcess();
			thisEntityProcess.setEntity(thisEntityName);
			thisEntityProcess.setProcess(thisProcessName);
			if(type.equals("source")) {
				newDataFlowInList = getConnectedNodeOfDataStore_CreateNewDataFlow(thisEntityProcess, dataStoreList, connectedElementName, transData, "source");
			}
			if(type.equals("target")) {
				newDataFlowOutList = getConnectedNodeOfDataStore_CreateNewDataFlow(thisEntityProcess, dataStoreList, connectedElementName, transData, "target");
			}
		}
		
		List<DataFlow> returnDataFlowList = new ArrayList<DataFlow>();
		if(stereotypeElementDataStore != null && stereotypeElementDataStore.getName().equals("DataStore")) {
			//The incoming or outgoing data flow of the process is from or to a dataStore.
			if(newDataFlowInList!=null && newDataFlowInList.size()>0)
				returnDataFlowList.addAll(newDataFlowInList);
			if(newDataFlowOutList!=null && newDataFlowOutList.size()>0)
				returnDataFlowList.addAll(newDataFlowOutList);
		}
		else {
			//The incoming or outgoing data flow of the process is from or to a external entity or this entity's process.
			returnDataFlowList.add(dataFlow);
		}
		return returnDataFlowList;
	}
	private static List<DataFlow> getConnectedNodeOfDataStore_CreateNewDataFlow(EntityProcess thisEntityProcess, List<DataStore> dataStoreList, String dataStoreName,List<Data> transData, String type) {
		//Get the connected node of the dataStore node and create the new dataFlow from entity's process to entity's process.
		List<DataFlow> newDataFlowList = new ArrayList<DataFlow>(); 
		List<String> transDataList = new ArrayList<String>();
		
		if(dataStoreList!=null && dataStoreList.size()>0) {
			for(DataStore dataStore:dataStoreList) {
				if(dataStore.getName().equals(dataStoreName)) {
					if(transData!=null && transData.size()>0) {
						for(Data data:transData) {
							transDataList.add(data.getDataName());
						}
						for(Data data:transData) {
							//Find transDataName in the data flow between the dataStore and the source entity/process of the data flow.
							String transDataName = data.getDataName();
//							System.out.println("getConnectedNodeOfDataStore_CreateNewDataFlow---transDataName:" + transDataName);
							if(type.equals("source")) {
								//The dataStore node is the source node of the data flow.
								//It requires to find the source node of the same data incoming from an external entity or a process of this entity.
								if(dataStore.getDataFlowInList()!=null && dataStore.getDataFlowInList().size()>0) {
									for(DataFlow dataFlow : dataStore.getDataFlowInList()) {
										if(dataFlow.getData_transmission_config().getData()!=null && dataFlow.getData_transmission_config().getData().size()>0) {
											List<String> dataInFlowList = new ArrayList<String>();
											for(Data dataInFlow : dataFlow.getData_transmission_config().getData()) {
												dataInFlowList.add(dataInFlow.getDataName());
											}
											if(dataInFlowList.contains(transDataName)) {
//												System.out.println("getConnectedNodeOfDataStore_CreateNewDataFlowIN---contains transDataName");

												//Find the data flow between the dataStore and the source entity/process of the data flow.
												//Create a new data flow based on this data flow.
												DataFlow newDataFlow= new DataFlow();
												
												EntityProcess sourceEntityProcess = dataFlow.getSource_entity_process();
												EntityProcess targetEntityProcess = thisEntityProcess;
												newDataFlow.setSource_entity_process(sourceEntityProcess);
												newDataFlow.setTarget_entity_process(targetEntityProcess);
//												System.out.println("getConnectedNodeOfDataStore_CreateNewDataFlowIN---source entity process" + sourceEntityProcess.getEntity() + " " + sourceEntityProcess.getProcess());
//												System.out.println("getConnectedNodeOfDataStore_CreateNewDataFlowIN---target entity process" + targetEntityProcess.getEntity() + " " + targetEntityProcess.getProcess());

												DataTransmissionConfig dataTransmissionConfig = dataFlow.getData_transmission_config();
												List<Data> newDataList = new ArrayList<Data>();
												newDataList.add(data);
												dataTransmissionConfig.setData(newDataList);
												newDataFlow.setData_transmission_config(dataTransmissionConfig);
												
												newDataFlowList.add(newDataFlow);										
											}
										}
									}
								}
							}
							if(type.equals("target")) {
								//The dataStore node is the target node of the data flow.
								//It requires to find the target node of the same data outgoing to an external entity or a process of this entity.
								if(dataStore.getDataFlowOutList()!=null && dataStore.getDataFlowOutList().size()>0) {
									for(DataFlow dataFlow : dataStore.getDataFlowOutList()) {
										if(dataFlow.getData_transmission_config().getData()!=null && dataFlow.getData_transmission_config().getData().size()>0) {
											List<String> dataOutFlowList = new ArrayList<String>();
											for(Data dataInFlow : dataFlow.getData_transmission_config().getData()) {
												dataOutFlowList.add(dataInFlow.getDataName());
											}
											if(dataOutFlowList.contains(transDataName)) {
//												System.out.println("getConnectedNodeOfDataStore_CreateNewDataFlowOUT---contains transDataName");

												//Find the data flow between the dataStore and the target entity/process of the data flow.
												//Create a new data flow based on this data flow.
												DataFlow newDataFlow= new DataFlow();
												
												EntityProcess sourceEntityProcess = thisEntityProcess;
												EntityProcess targetEntityProcess = dataFlow.getTarget_entity_process();
												newDataFlow.setSource_entity_process(sourceEntityProcess);
												newDataFlow.setTarget_entity_process(targetEntityProcess);

												DataTransmissionConfig dataTransmissionConfig = dataFlow.getData_transmission_config();
												List<Data> newDataList = new ArrayList<Data>();
												newDataList.add(data);
												dataTransmissionConfig.setData(newDataList);
												newDataFlow.setData_transmission_config(dataTransmissionConfig);
												
												newDataFlowList.add(newDataFlow);										
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return newDataFlowList;
	}

	public static Data getDataByNameFromDataList(String entity, String dataName, List<Data> dataList) {
		// Get data by name from dataList
		if(dataList != null && dataList.size()>0) {
			for(Data data:dataList) {
				if(data.getDataName().equals(dataName) && data.getEntity().equals(entity))
					return data;
			}
		}
		return null;
	}
}
