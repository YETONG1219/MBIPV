package MBIPV.utils;

public class DataAccess  {
	private EntityProcess entityProcess; 
	private String type;//grants, revokes, requests
	private String data;



	public EntityProcess getEntityProcess() {
		return entityProcess;
	}
	public void setEntityProcess(EntityProcess entityProcess) {
		this.entityProcess = entityProcess;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}	
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}	
}