package MBIPV.handlers;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import org.dom4j.DocumentException;
import MBIPV.formalModels.GenerateModelForV1;
import MBIPV.formalModels.GenerateModelForV2;
import MBIPV.formalModels.GenerateModelForV3;
import MBIPV.formalModels.GenerateModelForV4;
import MBIPV.formalModels.GenerateModelForV5;
import MBIPV.formalModels.GenerateModelForV6;
import MBIPV.utils.UMLModel;



public class UML2NuSMV_Verify {
	public static List<String> main(String dataAccessFileName, List<String> dataFileNameList, List<String> dataFlowFileNameList) throws DocumentException, IOException{

		    UMLModel model = GetUMLModel.main(dataAccessFileName, dataFileNameList, dataFlowFileNameList);//Get the UML models.   
		    String modelName = model.getName();
		   
		    File directory = new File("");
		    String dir = directory.getCanonicalPath() + "\\NuSMV-2.6.0-win64\\bin" ;
		    System.out.println("dir----" + dir);
		    String smvFile = dir;
			
			//Generate the formal models.
			List<String> modelForV1 = GenerateModelForV1.generateModel(model);
			List<String> modelForV2 = GenerateModelForV2.generateModel(model);
			List<String> modelForV3 = GenerateModelForV3.generateModel(model);
			List<String> modelForV4 = GenerateModelForV4.generateModel(model);
			List<String> modelForV5 = GenerateModelForV5.generateModel(model);
			List<String> modelForV6 = GenerateModelForV6.generateModel(model);
			
		   //File names of the formal models.
		    String smvFile1 = smvFile + "\\" + modelName + "_V1.smv";
		    String smvFile2 = smvFile + "\\" + modelName + "_V2.smv";
		    String smvFile3 = smvFile + "\\" + modelName + "_V3.smv";
		    String smvFile4 = smvFile + "\\" + modelName + "_V4.smv";
		    String smvFile5 = smvFile + "\\" + modelName + "_V5.smv";
		    String smvFile6 = smvFile + "\\" + modelName + "_V6.smv";

		   	//Write the files of the formal models.		
		    writeFile(modelForV1, smvFile1);
		    writeFile(modelForV2, smvFile2);
		    writeFile(modelForV3, smvFile3);
		    writeFile(modelForV4, smvFile4);
		    writeFile(modelForV5, smvFile5);
		    writeFile(modelForV6, smvFile6);
	
			//Verification results of the formal models.
			String resultV1 = "";
			String resultV2 = "";
			String resultV3 = "";
			String resultV4 = "";
			String resultV5 = "";
			String resultV6 = "";

			List<String> results = new ArrayList<String>();
			//Verify the formal models.
			if(modelForV1!=null && modelForV1.size()>0) {
				String fileName = smvFile1;
				String cmd = "cmd.exe /c NuSMV " + fileName;
				System.out.println("execute cmd" +cmd);
		        resultV1 = resultV1 + javaCmd(cmd , dir);					
			}
	        results.add(resultV1);
	        
			if(modelForV2!=null && modelForV2.size()>0) {
				String fileName = smvFile2;
				String cmd = "cmd.exe /c NuSMV " + fileName;
				System.out.println("execute cmd" +cmd);
		        resultV2 = resultV2 + javaCmd(cmd , dir);					
			}
	        results.add(resultV2);
	        
			if(modelForV3!=null && modelForV3.size()>0) {
				String fileName = smvFile3;
				String cmd = "cmd.exe /c NuSMV " + fileName;
				System.out.println("execute cmd" +cmd);
		        resultV3 = resultV3 + javaCmd(cmd , dir);					
			}
	        results.add(resultV3);
	        
			if(modelForV4!=null && modelForV4.size()>0) {
				String fileName = smvFile4;
				String cmd = "cmd.exe /c NuSMV " + fileName;
				System.out.println("execute cmd" +cmd);
		        resultV4 = resultV4 + javaCmd(cmd , dir);					
			}
	        results.add(resultV4);
	        
			if(modelForV5!=null && modelForV5.size()>0) {
				String fileName = smvFile5;
				String cmd = "cmd.exe /c NuSMV " + fileName;
				System.out.println("execute cmd" +cmd);
		        resultV5 = resultV5 + javaCmd(cmd , dir);					
			}
	        results.add(resultV5);
	        
			if(modelForV6!=null && modelForV6.size()>0) {
				String fileName = smvFile6;
				String cmd = "cmd.exe /c NuSMV " + fileName;
				System.out.println("execute cmd" +cmd);
		        resultV6 = resultV6 + javaCmd(cmd , dir);					
			}
	        results.add(resultV6);
	        
			
			if(results !=null && results.size()>0) {
				for(String r: results) {
					System.out.println("result: " + r);
				}
			}
			List<String> resList = new ArrayList<String>();
	    	if(results!=null && results.size()>0) {
	    		int i = 0;
	    		for(String s:results) {
	    			i++;
	    			if(!s.equals("")) {
	    				String res = "";
		    				res = "\n\n-------------------------------------------Verification Results of Privacy Violation (V"+ i + ")-------------------------------------------\n";        				    					     				    					
	    				res = res + s;
		    			resList.add(res);
	    			}
	    		}
//				System.out.println("resultList---" + result.toString() );
	    	}
			return resList;

		}

private static void writeFile(List<String> contentList,String FileName)  {
      try {
          BufferedWriter out = new BufferedWriter(new FileWriter(FileName));
          if(contentList!=null && contentList.size()>0) {
        	  for(String content:contentList) {
        		  if(!(content.contains("WARNING: single-value variable") && content.contains("has been stored as a constant"))) {
        			  //Our method stores some single-value variables which has only one value, for example, "publicData : {DiagnosisData};".
        			  //This causes NuSMV to output the "WARNING" messages. 
        			  //In this tool, to avoid displaying irrelevant information in the result list, this type of "WARNING" messages are not in the result list. 
                      out.write(content);
                      out.write("\r\n");        			  
        		  }
        	  }
          }
          out.close();
      } catch (IOException e) {
      }
}

public static String list2String(List<String> list) {
	String listText = "";
	if(list!=null && list.size()>0) {
		for(String s:list) {
			listText = listText + s + ", "; 
		}
		listText = listText.substring(0,listText.length() - 2);
	}
	return listText;
}
public static List<String> string2List(String s) {
	List<String> list = null;
	if(!s.equals("")) {
		list = new ArrayList<String>();
		String ss[] = s.split(", ");
		for(String s1:ss) {
			list.add(s1);
		}
	}
	return list;
}

public static String javaCmd(String command, String dir) {
    StringBuilder result = new StringBuilder();
    Process p = null;
	Runtime rt = Runtime.getRuntime();  
	try {  
	 p = rt.exec(command ,null,new File(dir));  
	 final InputStream is1 = p.getInputStream();   
	 final InputStream is2 = p.getErrorStream();  
	 new Thread() {  
	    public void run() {  
	       BufferedReader br1 = new BufferedReader(new InputStreamReader(is1));  
	        try {  
	            String line1 = null;  
	            while ((line1 = br1.readLine()) != null) {  
	                  if (line1 != null){
	                	if(!line1.contains("***") && !line1.replaceAll("\\s*", "").equals("")) {
	                		result.append(line1).append('\n');
	                	}
	                  }  
	              }  
	        } catch (IOException e) {  
	             e.printStackTrace();  
	        }  
	        finally{  
	             try {  
	               is1.close();  
	             } catch (IOException e) {  
	                e.printStackTrace();  
	            }  
	          }  
	        }  
	     }.start();  
	                                
	   new Thread() {   
	      public void  run() {   
	       BufferedReader br2 = new  BufferedReader(new  InputStreamReader(is2));   
	          try {   
	             String line2 = null ;   
	             while ((line2 = br2.readLine()) !=  null ) {   
	                  if (line2 != null){
	                	  if(!line2.contains("***") && !line2.replaceAll("\\s*", "").equals("")) {
	                		  result.append(line2).append('\n');
	                	  }
	                  }  
	             }   
	           } catch (IOException e) {   
	                 e.printStackTrace();  
	           }   
	          finally{  
	             try {  
	                 is2.close();  
	             } catch (IOException e) {  
	                 e.printStackTrace();  
	             }  
	           }  
	        }   
	      }.start();    
	                                
	      p.waitFor();  
	      p.destroy();   
	    } catch (Exception e) {  
	            try{  
	                p.getErrorStream().close();  
	                p.getInputStream().close();  
	                p.getOutputStream().close();  
	                }  
	             catch(Exception ee){}  
	          }  
    return result.toString();
}  

}
