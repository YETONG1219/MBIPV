package MBIPV.formalModels;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import MBIPV.utils.Data;
import MBIPV.utils.UMLModel;

public class GenerateModelForV4 {
	//Generate the formal model to verify if V4 is violated.
	public static List<String> generateModel(UMLModel umlModel) throws IOException{
		List<String> model = new ArrayList<String>();
		List<Data> dataList = umlModel.getDataList();
		List<String> entityHasDataList = new ArrayList<String>();//The list of entities that have data.
		List<String> entityHasPublicAndExternalDataList = new ArrayList<String>();//The list of entities that have data.
		List<String> entityHasPrivacyDataList = new ArrayList<String>();//The list of entities that have data.

		
		if(dataList!=null && dataList.size()>0) {
			for(Data data:dataList) {
				String entity = data.getEntity();
				if(!entityHasDataList.contains(entity))
					entityHasDataList.add(entity);
			}
		}
		//Generate the data module of each entity that has data.
		if(entityHasDataList!=null && entityHasDataList.size()>0) {
			for(String entity:entityHasDataList) {
				if(dataList!=null && dataList.size()>0) {
					List<String> publicDataList = new ArrayList<String>();
					List<String> privacyDataList = new ArrayList<String>();
					List<String> externalDataList = new ArrayList<String>();
					for(Data data:dataList) {
						String entityName = data.getEntity();
						if(entityName.equals(entity)) {
							String dataName = data.getDataName();
							String isPrivacy = data.getIsPrivacy();
							String fromExternalEntity = data.getFromExternalEntity();
							
							if(isPrivacy.equals("true")) {
								privacyDataList.add(dataName);
							}
							else {
								publicDataList.add(dataName);
							}
							if(fromExternalEntity.equals("true")) {
								externalDataList.add(dataName);
							}
						}
					}
					String entityDataModule = "MODULE " + entity + "Data()\r\n";
					String publicDataText = "";
					String privacyDataText = "";
					String externalDataText = "";
					if(publicDataList!=null && publicDataList.size()>0) {
						for(String publicData:publicDataList) {
							publicDataText = publicDataText + publicData + ", ";
						}
						publicDataText = publicDataText.substring(0,publicDataText.length() - 2);
						if(publicDataText.contains(",")) {
							if(!entityDataModule.contains("VAR")) {
								entityDataModule = entityDataModule + "VAR\r\n";
							}
							publicDataText = "\tpublicData : {" + publicDataText + "};\r\n";
							entityDataModule = entityDataModule + publicDataText;
						}
						else
							publicDataText = "\tpublicData := " + publicDataText + ";\r\n";
					}
					if(privacyDataList!=null && privacyDataList.size()>0) {
						if(!entityHasPrivacyDataList.contains(entity))
							entityHasPrivacyDataList.add(entity);
						for(String privacyData:privacyDataList) {
							privacyDataText = privacyDataText + privacyData + ", ";
						}
						privacyDataText = privacyDataText.substring(0,privacyDataText.length() - 2);
						if(privacyDataText.contains(",")) {
							if(!entityDataModule.contains("VAR")) {
								entityDataModule = entityDataModule + "VAR\r\n";
							}
							privacyDataText = "\tprivacyData : {" + privacyDataText + "};\r\n";
							entityDataModule = entityDataModule + privacyDataText;
						}
						else
							privacyDataText = "\tprivacyData := " + privacyDataText + ";\r\n";
					}
					if(publicDataList!=null && publicDataList.size()>0 && externalDataList!=null && externalDataList.size()>0) {
						if(!entityHasPublicAndExternalDataList.contains(entity))
							entityHasPublicAndExternalDataList.add(entity);
					}
					if(externalDataList!=null && externalDataList.size()>0) {
						for(String externalData:externalDataList) {
							externalDataText = externalDataText + externalData + ", ";
						}
						externalDataText = externalDataText.substring(0,externalDataText.length() - 2);
						if(externalDataText.contains(",")) {
							if(!entityDataModule.contains("VAR")) {
								entityDataModule = entityDataModule + "VAR\r\n";
							}
							externalDataText = "\texternalData : {" + externalDataText + "};\r\n";
							entityDataModule = entityDataModule + externalDataText;
						}
						else
							externalDataText = "\texternalData := " + externalDataText + ";\r\n";
					}
					if(publicDataText.contains(":=")) {
						if(!entityDataModule.contains("DEFINE")) {
							entityDataModule = entityDataModule + "DEFINE\r\n";
						}
						entityDataModule = entityDataModule + publicDataText;
					}
					if(privacyDataText.contains(":=")) {
						if(!entityDataModule.contains("DEFINE")) {
							entityDataModule = entityDataModule + "DEFINE\r\n";
						}
						entityDataModule = entityDataModule + privacyDataText;
					}
					if(externalDataText.contains(":=")) {
						if(!entityDataModule.contains("DEFINE")) {
							entityDataModule = entityDataModule + "DEFINE\r\n";
						}
						entityDataModule = entityDataModule + externalDataText;
					}
					model.add(entityDataModule);
				}		
			}
		}
		//Generate the main module.
		String mainModule = "MODULE main\r\nVAR";
		model.add(mainModule);
		if(entityHasDataList!=null && entityHasDataList.size()>0) {
			for(String entityName:entityHasDataList) {
				model.add("\t" + entityName + "Data" + " : " + entityName + "Data" + "();");
			}
		}
		//Generate privacy properties for V4.
		if(entityHasDataList!=null && entityHasDataList.size()>0) {
			model.add("\r\n-----------------------Privacy Properties (V4)----------------------------");
			int size = entityHasDataList.size();
			for(int i=0;i<size;i++) {
				for(int j=0;j<size;j++) {
					if(j != i) {
						String entity_i = entityHasDataList.get(i);
						String entity_j = entityHasDataList.get(j);
						if(entityHasPublicAndExternalDataList.contains(entity_i) && entityHasPrivacyDataList.contains(entity_j)) {
							String property = "CTLSPEC !EF(" + entity_i + "Data.externalData = " + entity_j + "Data.privacyData & "
									+ entity_i + "Data.externalData = " + entity_i + "Data.publicData);--/*For V4*/";
							if(!model.contains(property))
								model.add(property);
						}
					}
				}
			}
		}
		return model;
	}
}
	

