package MBIPV.utils;

public class DataFlow  {
	private EntityProcess source_entity_process; 
	private EntityProcess target_entity_process; 
	private DataTransmissionConfig data_transmission_config;	


	public EntityProcess getSource_entity_process() {
		return source_entity_process;
	}
	public void setSource_entity_process(EntityProcess source_entity_process) {
		this.source_entity_process = source_entity_process;
	}
	public EntityProcess getTarget_entity_process() {
		return target_entity_process;
	}
	public void setTarget_entity_process(EntityProcess target_entity_process) {
		this.target_entity_process = target_entity_process;
	}
	public DataTransmissionConfig getData_transmission_config() {
		return data_transmission_config;
	}
	public void setData_transmission_config(DataTransmissionConfig data_transmission_config) {
		this.data_transmission_config = data_transmission_config;
	}	
}