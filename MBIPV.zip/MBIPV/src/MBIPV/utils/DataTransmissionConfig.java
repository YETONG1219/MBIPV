package MBIPV.utils;

import java.util.List;

public class DataTransmissionConfig  {
	private List<Data> data; 
	private String NetType; 
	private String ProtocolType; 
	private String PwdType; 
	private String CipherType; 
	private String SigType; 
	private String HashingType; 

	public List<Data> getData() {
		return data;
	}
	public void setData(List<Data> data) {
		this.data = data;
	}
	public String getNetType() {
		return NetType;
	}
	public void setNetType(String NetType) {
		this.NetType = NetType;
	}
	public String getProtocolType() {
		return ProtocolType;
	}
	public void setProtocolType(String ProtocolType) {
		this.ProtocolType = ProtocolType;
	}	
	public String getPwdType() {
		return PwdType;
	}
	public void setPwdType(String PwdType) {
		this.PwdType = PwdType;
	}	
	public String getCipherType() {
		return CipherType;
	}
	public void setCipherType(String CipherType) {
		this.CipherType = CipherType;
	}	
	public String getSigType() {
		return SigType;
	}
	public void setSigType(String SigType) {
		this.SigType = SigType;
	}	
	public String getHashingType() {
		return HashingType;
	}
	public void setHashingType(String HashingType) {
		this.HashingType = HashingType;
	}
}