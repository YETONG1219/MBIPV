package MBIPV.views;


import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.part.*;
import org.eclipse.wb.swt.SWTResourceManager;

import MBIPV.handlers.UML2NuSMV_Verify;
import MBIPV.utils.XMLFileFilter;

import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowData;
import org.eclipse.swt.layout.RowLayout;
import org.dom4j.DocumentException;
import org.eclipse.ui.*;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.TabItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Image;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.inject.Inject;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;

public class MBIPVView extends ViewPart {
	private Text text;
	private Text text_1;
	private Text text_2;
	private Text text_3;
	/**
	 * The ID of the view as specified by the extension.
	 */
	public static final String ID = "MBIPV.views.MBIPVView";

	@Inject IWorkbench workbench;
	@Override
	public void createPartControl(Composite parent) {

		try {
			todo(parent);
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	public void todo(Composite parent) throws DocumentException{

		TabFolder tabFolder = new TabFolder(parent,SWT.BORDER);
		TabItem tabItem1 = new TabItem(tabFolder, SWT.NONE);
		tabItem1.setText("MBIPV Verification");

		Composite compsoite1 = new Composite(tabFolder,SWT.NONE|SWT.V_SCROLL);
        tabItem1.setControl(compsoite1);
        
        compsoite1.setLayout(new GridLayout(3, false));
		GridData gd_tabFolder = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_tabFolder.heightHint = 45;
		tabFolder.setLayoutData(gd_tabFolder);
		
		Label lblNewLabel = new Label(compsoite1, SWT.NONE);
		lblNewLabel.setAlignment(SWT.LEFT);
		lblNewLabel.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblNewLabel.setText("Choose UML Models:");
		lblNewLabel.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 11, SWT.NORMAL));
		new Label(compsoite1, SWT.NONE);
		new Label(compsoite1, SWT.NONE);
		
		text = new Text(compsoite1, SWT.BORDER);
		GridData gd_text = new GridData(SWT.LEFT, SWT.CENTER, true, false, 2, 1);
		gd_text.widthHint = 594;
		text.setLayoutData(gd_text);
		text.setBackground(SWTResourceManager.getColor(240, 248, 255));

		Button btnNewButton = new Button(compsoite1, SWT.NONE);
		GridData gd_btnNewButton = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_btnNewButton.widthHint = 185;
		btnNewButton.setLayoutData(gd_btnNewButton);
		btnNewButton.setText("Choose Data Access Model");
		btnNewButton.setBackground(SWTResourceManager.getColor(70,130,180));
		btnNewButton.setForeground(SWTResourceManager.getColor(255,255,255));
		btnNewButton.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 10, SWT.NORMAL));
		btnNewButton.addSelectionListener(new SelectionAdapter() {
		public void widgetSelected(SelectionEvent e) {
			    String dataAccessFileName = "";
				JFrame frame = new JFrame();
				String dir = "E:\\papyrus";

				JFileChooser chooser = new JFileChooser();
				chooser.setCurrentDirectory(new File(dir));
				chooser.setDialogTitle("Choose UML model"); 	
			    XMLFileFilter xmlFilter = new XMLFileFilter();   
			    chooser.addChoosableFileFilter(xmlFilter);
			    chooser.setFileFilter(xmlFilter);

				int flag = chooser.showOpenDialog(frame);
				if (flag == JFileChooser.APPROVE_OPTION) {
					System.out.println("Choose the data access file��" + chooser.getSelectedFile().getAbsolutePath());
					dataAccessFileName = chooser.getSelectedFile().getAbsolutePath();
					text.setText(dataAccessFileName);
				}
		}
	});
		text_1 = new Text(compsoite1, SWT.BORDER);
		
		GridData gd_text_1 = new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1);
		gd_text_1.widthHint = 594;
		text_1.setLayoutData(gd_text_1);
		text_1.setBackground(SWTResourceManager.getColor(240, 248, 255));

		Button btnNewButton_1 = new Button(compsoite1, SWT.NONE);
		GridData gd_btnNewButton_1 = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_btnNewButton_1.widthHint = 185;
		btnNewButton_1.setLayoutData(gd_btnNewButton_1);
		btnNewButton_1.setText("Choose Data Models");
		btnNewButton_1.setBackground(SWTResourceManager.getColor(70,130,180));
		btnNewButton_1.setForeground(SWTResourceManager.getColor(255,255,255));
		btnNewButton_1.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 10, SWT.NORMAL));
		btnNewButton_1.addSelectionListener(new SelectionAdapter() {
		public void widgetSelected(SelectionEvent e) {
			text_1.setText("");

			List<String>  UMLFileNameList = new ArrayList<String>();
			JFrame frame = new JFrame();
			String dir = "E:\\papyrus";

			JFileChooser chooser = new JFileChooser();
			chooser.setCurrentDirectory(new File(dir));
			chooser.setDialogTitle("Choose UML model"); 	
		    XMLFileFilter xmlFilter = new XMLFileFilter();   
		    chooser.addChoosableFileFilter(xmlFilter);
		    chooser.setFileFilter(xmlFilter);
		    chooser.setMultiSelectionEnabled(true);

			int flag = chooser.showOpenDialog(frame);
			if (flag == JFileChooser.APPROVE_OPTION) {
				File[] files = chooser.getSelectedFiles();
				for(File file:files) {
					System.out.println("Choose the data file��" + file.getAbsolutePath());
					UMLFileNameList.add(file.getAbsolutePath());
					text_1.append(file.getAbsolutePath() + " ");
				}
			}
		}
	});
		text_2 = new Text(compsoite1, SWT.BORDER);
		GridData gd_text_2 = new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1);
		gd_text_2.widthHint = 594;
		text_2.setLayoutData(gd_text_2);
		text_2.setBackground(SWTResourceManager.getColor(240, 248, 255));

		Button btnNewButton_2 = new Button(compsoite1, SWT.NONE);
		GridData gd_btnNewButton_2 = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_btnNewButton_2.widthHint = 185;
		btnNewButton_2.setLayoutData(gd_btnNewButton_2);
		btnNewButton_2.setText("Choose Data Flow Models");
		btnNewButton_2.setBackground(SWTResourceManager.getColor(70,130,180));
		btnNewButton_2.setForeground(SWTResourceManager.getColor(255,255,255));
		btnNewButton_2.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 10, SWT.NORMAL));
		btnNewButton_2.addSelectionListener(new SelectionAdapter() {
		public void widgetSelected(SelectionEvent e) {
			text_2.setText("");

			List<String>  UMLFileNameList = new ArrayList<String>();
			JFrame frame = new JFrame();
			String dir = "E:\\papyrus";

			JFileChooser chooser = new JFileChooser();
			chooser.setCurrentDirectory(new File(dir));
			chooser.setDialogTitle("Choose UML model"); 	
		    XMLFileFilter xmlFilter = new XMLFileFilter();   
		    chooser.addChoosableFileFilter(xmlFilter);
		    chooser.setFileFilter(xmlFilter);
		    chooser.setMultiSelectionEnabled(true);

			int flag = chooser.showOpenDialog(frame);
			if (flag == JFileChooser.APPROVE_OPTION) {
				File[] files = chooser.getSelectedFiles();
				for(File file:files) {
					System.out.println("Choose the data flow file��" + file.getAbsolutePath());
					UMLFileNameList.add(file.getAbsolutePath());
					text_2.append(file.getAbsolutePath() + " ");
				}
			}
		}
	});
		new Label(compsoite1, SWT.NONE);
		Button btnNewButton_3 = new Button(compsoite1, SWT.NONE);
		GridData gd_btnNewButton_3 = new GridData(SWT.LEFT, SWT.CENTER, false, false, 1, 1);
		gd_btnNewButton_3.widthHint = 455;
		gd_btnNewButton_3.heightHint = 40;
		btnNewButton_3.setLayoutData(gd_btnNewButton_3);
		btnNewButton_3.setText("Generate Formal Models and Verify");
		btnNewButton_3.setBackground(SWTResourceManager.getColor(255,140,0));
		btnNewButton_3.setForeground(SWTResourceManager.getColor(255,255,224));
		btnNewButton_3.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 12, SWT.BOLD));
		btnNewButton_3.addSelectionListener(new SelectionAdapter() {
		public void widgetSelected(SelectionEvent e) {
			    text_3.setText("");
			    String dataAccessFileName = text.getText();
			    String dataFileNames = text_1.getText();
			    String dataFileList[] = dataFileNames.split(" ");
			    List<String> dataFileNameList = Arrays.asList(dataFileList);
			    String dataFlowFileNames = text_2.getText();
			    String dataFlowFileList[] = dataFlowFileNames.split(" ");
			    List<String> dataFlowFileNameList = Arrays.asList(dataFlowFileList);

				if (dataAccessFileName != "" && dataFileNameList!=null && dataFileNameList.size()>0 && dataFlowFileNameList!=null && dataFlowFileNameList.size()>0) {
					try {
				    	List<String> resultList = null;
				    	long stime = System.currentTimeMillis();
				    	resultList = UML2NuSMV_Verify.main(dataAccessFileName, dataFileNameList, dataFlowFileNameList);
				    	long etime = System.currentTimeMillis();
				        // Calculate execution time
				        System.out.printf("Time cost for formal modeling and verification��%d ms.", (etime - stime));
				    	if(resultList!=null && resultList.size()>0) {
				    		for(String res:resultList) {
        		    			text_3.append(res);        				    			
				    		}
				    	}

					} catch (DocumentException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
		}
	});
		new Label(compsoite1, SWT.NONE);

		Label lblNewLabel_1 = new Label(compsoite1, SWT.NONE);
		lblNewLabel_1.setAlignment(SWT.CENTER);
		lblNewLabel_1.setText("Verification Results:");
		lblNewLabel_1.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 11, SWT.NORMAL));
		new Label(compsoite1, SWT.NONE);
		new Label(compsoite1, SWT.NONE);
		
		text_3 = new Text(compsoite1, SWT.BORDER | SWT.READ_ONLY | SWT.H_SCROLL | SWT.V_SCROLL | SWT.CANCEL | SWT.WRAP);
		GridData gd_text_3 = new GridData(SWT.LEFT, SWT.CENTER, false, false, 3, 1);
		gd_text_3.heightHint = 630;
		gd_text_3.widthHint = 792;
		text_3.setLayoutData(gd_text_3);
		text_3.setBackground(SWTResourceManager.getColor(255,255,240));

	}

	@Override
	public void setFocus() {
		
	}
}
