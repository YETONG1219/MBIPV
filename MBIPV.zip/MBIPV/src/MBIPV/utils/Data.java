package MBIPV.utils;

public class Data  {
	private String dataName; 
	private String entity; 
	private String isPrivacy; //True or false.
	private String fromExternalEntity; //True or false.
	private String dependsOnData;

	public String getDataName() {
		return dataName;
	}
	public void setDataName(String dataName) {
		this.dataName = dataName;
	}
	public String getEntity() {
		return entity;
	}
	public void setEntity(String entity) {
		this.entity = entity;
	}
	public String getIsPrivacy() {
		return isPrivacy;
	}
	public void setIsPrivacy(String isPrivacy) {
		this.isPrivacy = isPrivacy;
	}
	public String getFromExternalEntity() {
		return fromExternalEntity;
	}
	public void setFromExternalEntity(String fromExternalEntity) {
		this.fromExternalEntity = fromExternalEntity;
	}
	public String getDependsOnData() {
		return dependsOnData;
	}
	public void setDependsOnData(String dependsOnData) {
		this.dependsOnData = dependsOnData;
	}
}