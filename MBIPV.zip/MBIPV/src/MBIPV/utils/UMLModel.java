package MBIPV.utils;

import java.util.List;

public class UMLModel  {
	private String name;
	private List<Entity> entityList; 
	private List<DataAccess> dataAccessList; 
	private List<Data> dataList;


	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Entity> getEntityList() {
		return entityList;
	}
	public void setEntityList(List<Entity> entityList) {
		this.entityList = entityList;
	}
	public List<DataAccess> getDataAccessList() {
		return dataAccessList;
	}
	public void setDataAccessList(List<DataAccess> dataAccessList) {
		this.dataAccessList = dataAccessList;
	}
	public List<Data> getDataList() {
		return dataList;
	}
	public void setDataList(List<Data> dataList) {
		this.dataList = dataList;
	}
}