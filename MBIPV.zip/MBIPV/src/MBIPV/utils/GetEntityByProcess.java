package MBIPV.utils;

import java.io.File;
import java.util.List;
import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;



public class GetEntityByProcess {
	public static Element getElement(String id, String fileName) throws DocumentException{

    	   File xmlFile = new File(fileName);
    	   SAXReader sax = new SAXReader();
    	   Document document = sax.read(xmlFile);
    	   Element root = document.getRootElement();
    	   Element element = GetEntityByProcess.getNodes(id,root,null,fileName);  
   	return element;
	}


public static Element getNodes(String id,Element node,Element element,String fileName) {

	Element processElement = null;
	if(node.attributeValue("type")!=null && node.attributeValue("type").equals("uml:Association")) {
	    List<Element> listElement = node.elements();
	    for (Element e : listElement) {
			List<Attribute> attrList = e.attributes();
			if(attrList!=null && attrList.size()>0) {
				for(Attribute attribute:attrList) {
					if(attribute.getName().equals("type") && attribute.getValue().equals(id)) {
						processElement = e;
					}
				}
			}
	    }
	    if(processElement != null) {
	   	    for (Element e : listElement) {
	   			List<Attribute> attrList = e.attributes();
	   			if(attrList!=null && attrList.size()>0) {
	   				for(Attribute attribute:attrList) {
	   					if(attribute.getName().equals("type") && !attribute.getValue().equals(id) && !attribute.getValue().equals("uml:Property")) {
	   						element = e;
	   					}
	   				}
	   			}
	   	    }
	    }
	}
    
    List<Element> listElement = node.elements();
    for (Element e : listElement) {
    	element = getNodes(id,e,element,fileName);
    }
	return  element;   
}	
}
