package MBIPV.utils;

import java.util.List;

public class Entity  {
	private String entityName; 
	private List<Data> dataList;
	private List<Data> externalDataList;
	private List<Process> processList;
	private List<DataStore> dataStoreList;

	public String getEntityName() {
		return entityName;
	}
	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}
	public List<Data> getDataList() {
		return dataList;
	}
	public void setDataList(List<Data> dataList) {
		this.dataList = dataList;
	}
	public List<Data> getExternalDataList() {
		return externalDataList;
	}
	public void setExternalDataList(List<Data> externalDataList) {
		this.externalDataList = externalDataList;
	}
	public List<Process> getProcessList() {
		return processList;
	}
	public void setProcessList(List<Process> processList) {
		this.processList = processList;
	}
	public List<DataStore> getDataStoreList() {
		return dataStoreList;
	}
	public void setDataStoreList(List<DataStore> dataStoreList) {
		this.dataStoreList = dataStoreList;
	}
}