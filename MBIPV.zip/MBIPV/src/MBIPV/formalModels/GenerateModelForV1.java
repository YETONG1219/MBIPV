package MBIPV.formalModels;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import MBIPV.handlers.GetUMLModel;
import MBIPV.utils.Data;
import MBIPV.utils.DataAccess;
import MBIPV.utils.DataFlow;
import MBIPV.utils.Entity;
import MBIPV.utils.EntityProcess;
import MBIPV.utils.UMLModel;
import MBIPV.utils.Process;

public class GenerateModelForV1 {
	//Generate the formal model to verify if V1 is violated.
	public static List<String> generateModel(UMLModel umlModel) throws IOException{
		List<String> model = new ArrayList<String>();
		//Get process list of entities.
		List<Entity> entityList = umlModel.getEntityList();
		List<Process> processList = new ArrayList<Process>();
		if(entityList!=null && entityList.size()>0) {
			for(Entity entity:entityList) {
				processList.addAll(entity.getProcessList());				
			}
		}
		//Generate process modules.
		List<String> externalDataAccessList = new ArrayList<String>();//The list of external data access of each entity.
		List<String> firstLineOfProcess = null;
		if(processList!=null && processList.size()>0) {
			firstLineOfProcess = new ArrayList<String>();
			for(Process process:processList) {
				List<String> processModule = generateProcessModule(process, entityList, umlModel.getDataList(), externalDataAccessList);
				firstLineOfProcess.add(processModule.get(0));//Save the first line of the module.
				model.addAll(processModule);//Add each process module.
			}
		}
		//Get the dataAccess model and generate the permission module for each entity.
		List<DataAccess> dataAccessList = umlModel.getDataAccessList();
		List<String> entityGrantPermission = new ArrayList<String>();
		List<DataAccess> dataGrantList = new ArrayList<DataAccess>();
		List<DataAccess> dataRequestList = new ArrayList<DataAccess>();
		if(dataAccessList!=null && dataAccessList.size()>0) {
			for(DataAccess dataAccess:dataAccessList) {
				if(dataAccess.getType().equals("grants")) {
					dataGrantList.add(dataAccess);
					String entity = dataAccess.getEntityProcess().getEntity();
					if(!entityGrantPermission.contains(entity)) {
						entityGrantPermission.add(entity);
					}
				}
				if(dataAccess.getType().equals("requests")) {
					dataRequestList.add(dataAccess);
				}
			}
		}
		List<String> entityHasPermissionModule = new ArrayList<String>();
		if(entityList!=null && entityList.size()>0) {
			for(Entity entity:entityList) {
				String entityName = entity.getEntityName();
				List<String> permissionModule = generatePermissionModule(entityName, dataGrantList, dataRequestList, externalDataAccessList);
				if(permissionModule!=null) {
					model.addAll(permissionModule);//Add each permission module.
					entityHasPermissionModule.add(entity.getEntityName());
				}
			}			
		}
//		if(entityGrantPermission!=null && entityGrantPermission.size()>0) {
//			for(String entity:entityGrantPermission) {
//				List<String> permissionModule = generatePermissionModule(entity, dataGrantList, dataRequestList, externalDataAccessList);
//				model.addAll(permissionModule);//Add each permission module.
//			}
//		}
		//Generate the main module.
		String mainModule = "MODULE main\r\nVAR\r\n";
	
		if(firstLineOfProcess!=null && firstLineOfProcess.size()>0) {
			for(String firstline:firstLineOfProcess) {
				String lineInMain = firstline.replace("MODULE ", "");
//				System.out.println("MBIPV.formalModels.GenerateModelForV1.generateModel---lineInMain" + lineInMain);
				String moduleName = lineInMain.split("\\(")[0];
				String processModule = lineInMain.split("\\(")[1].replace(")", "").replace("_input", ".output");
				mainModule = mainModule + "\t" + moduleName + " : " + moduleName + "(" + processModule + ");\r\n";
			}
			model.add(mainModule);
		}
		if(entityHasPermissionModule!=null && entityHasPermissionModule.size()>0) {
			for(String entity:entityHasPermissionModule) {
				model.add("\t" + entity + "_Permission : " + entity + "_Permission();");
			}
		}
		//Generate privacy properties.
		if(externalDataAccessList!=null && externalDataAccessList.size()>0) {
			model.add("\r\n-----------------------Privacy Properties (V1)----------------------------");
			for(String externalDataAccess: externalDataAccessList) {
				String targetEntityProcess = externalDataAccess.split(" ")[0];
				String sourceEntityProcess = externalDataAccess.split(" ")[1];
				String inputData = externalDataAccess.split(" ")[2];
				String privacyProperty = "CTLSPEC !EF(" + targetEntityProcess + "." + sourceEntityProcess + "_input = " + sourceEntityProcess + ".output"
						+ " & " + sourceEntityProcess.split("_")[0] + "_Permission." + targetEntityProcess + "_AccessTo" + inputData + " != TRUE);--/*For V1*/"; 
				if(!model.contains(privacyProperty))
					model.add(privacyProperty);	
			}
		}
		
		return model;
	}

	private static List<String> generatePermissionModule(String entity, List<DataAccess> dataGrantList, List<DataAccess> dataRequestList, List<String> externalDataAccessList) {
		// Generate the permission module of each entity in the list of entityGrantPermission.
		List<String> entityPermissionModule = null;		
		if(dataGrantList!=null && dataGrantList.size()>0) {
			for(DataAccess dataAccessGrant:dataGrantList) {
				if(dataAccessGrant.getEntityProcess().getEntity().equals(entity)) {
					if(entityPermissionModule==null) {
						entityPermissionModule = new ArrayList<String>();
						entityPermissionModule.add("MODULE " + entity + "_Permission()");
						entityPermissionModule.add("DEFINE");
					}			
					String data = dataAccessGrant.getData();
					if(data != "" && dataRequestList !=null && dataRequestList.size()>0) {
						for(DataAccess dataAccessRequest:dataRequestList) {
							String requestData = dataAccessRequest.getData();
							if(data.equals(requestData)) {
								String requestEntity = dataAccessRequest.getEntityProcess().getEntity();
								String requestProcess = dataAccessRequest.getEntityProcess().getProcess();
								String defineText = "\t" + requestEntity + "_" + requestProcess + "_AccessTo" + data + " := TRUE;";
								if(!entityPermissionModule.contains(defineText))
									entityPermissionModule.add(defineText);
							}
						}
					}
				}
			}
		}
		if(externalDataAccessList!=null && externalDataAccessList.size()>0) {
			for(String externalDataAccess:externalDataAccessList) {
				String targetEntityProcess = externalDataAccess.split(" ")[0];
				String sourceEntityProcess = externalDataAccess.split(" ")[1];
				String sourceEntity = sourceEntityProcess.split("_")[0];
				String data = externalDataAccess.split(" ")[2];
				if(sourceEntity.equals(entity)) {
					if(entityPermissionModule == null) {
						entityPermissionModule = new ArrayList<String>();
						entityPermissionModule.add("MODULE " + entity + "_Permission()");
						entityPermissionModule.add("DEFINE");
					}
					if(!entityPermissionModule.contains("\t" + targetEntityProcess + "_" + "AccessTo" + data + " := TRUE;"))
						entityPermissionModule.add("\t" + targetEntityProcess + "_" + "AccessTo" + data + " := FALSE;");
					}
			}
		}
		return entityPermissionModule;
	}

	private static List<String> generateProcessModule(Process process, List<Entity> entityList, List<Data> dataList, List<String> externalDataAccessList) {
		// Generate the module of the process.
		List<String> module = new ArrayList<String>();
		String thisEntity = process.getEntity();
		String thisProcess = process.getName();
		String moduleName = thisEntity + "_" + thisProcess;

		//Get the input list.
		List<String> inputList = null;//It saves the list of inputData,sourceEntity and sourceProcess. 
		List<DataFlow> dataFlowInList = process.getDataFlowInList();
		List<String> dataNameList = null;
		if(dataFlowInList!=null && dataFlowInList.size()>0) {
			inputList = new ArrayList<String>();
			for(DataFlow dataFlow: dataFlowInList) {
				EntityProcess dataFlowSource = dataFlow.getSource_entity_process();
				String sourceEntity = dataFlowSource.getEntity();
				String sourceProcess = dataFlowSource.getProcess();
				List<Data> dataInFLowList = dataFlow.getData_transmission_config().getData();
				dataNameList = null;
				if(dataInFLowList!=null && dataInFLowList.size()>0) {
					dataNameList = new ArrayList<String>();
					for(Data data: dataInFLowList) {
						dataNameList.add(data.getDataName());
					}
				}
				if(sourceProcess.equals("")) {
					//Data flows from an external entity.
					String externalEntity = sourceEntity;
					if(dataNameList!=null && dataNameList.size()>0) {
						for(String data:dataNameList) {
							String externalSourceProcess = getExternalSourceProcess(data,thisEntity,externalEntity,entityList);
							String input = externalEntity + " " + externalSourceProcess + " " + data;
							inputList.add(input);
							if(!externalEntity.equals(thisEntity))
							//Add the data to the list of external data access of each entity.
								externalDataAccessList.add(thisEntity + "_" + thisProcess + " " + externalEntity + "_" + externalSourceProcess + " " + data);
						}
					}
				}
				else {
					//Data flows from a process in this entity.
					for(String data:dataNameList) {
						String input = thisEntity + " " + sourceProcess + " " + data;
						inputList.add(input);
					}
				}
				
			}
		}
		//Get the output list.
		List<String> outputList = null;//It saves the list of outputData,sourceEntity and sourceProcess. 
		List<DataFlow> dataFlowOutList = process.getDataFlowOutList();
		if(dataFlowOutList!=null && dataFlowOutList.size()>0) {
			outputList = new ArrayList<String>();
			for(DataFlow dataFlow:dataFlowOutList) {
				List<Data> dataOutList = dataFlow.getData_transmission_config().getData();
				if(dataOutList!=null && dataOutList.size()>0) {
					for(Data dataOut: dataOutList) {
						String dName = dataOut.getDataName();
						if(!outputList.contains(dName))
							outputList.add(dName);
					}
				}
			}
		}

		//Generate the transitions of output data.
		List<String> transitionList = new ArrayList<String>();
		String nextOutPut = "";
		String caseTrue = "None";
		if(outputList!=null && outputList.size()>0) {
			nextOutPut = "next(output):=case\r\n";
			for(String outputDataName: outputList) {
				Data data = GetUMLModel.getDataByNameFromDataList(thisEntity, outputDataName, dataList);
				String dependsOnData = data.getDependsOnData();
				boolean flag = false;
				if(inputList!=null && inputList.size()>0) {
					//Generate the "case" of the transition.
					for(String in:inputList) {
						String ins[]= in.split(" ");
						//Get the source entity, source process and data name of each input data.
						String sourceEntity = ins[0];
						String sourceProcess = ins[1];
						String dataNameInInputList = ins[2];
						if(!dependsOnData.equals("") && dependsOnData.equals(dataNameInInputList)) {
							//The output data depends on the input data.
							String input = sourceEntity + "_" + sourceProcess + "_input = " + dependsOnData;
							String transition = "(" + input + ")" + ":" + outputDataName + ";\r\n";
							transitionList.add(transition);
							flag = true;
						}
						if (dataNameInInputList.equals(outputDataName)) {
							//The output data depends on the input data.
							String input = sourceEntity + "_" + sourceProcess + "_input = " + outputDataName;
							String transition = "(" + input + ")" + ":" + outputDataName + ";\r\n";
							transitionList.add(transition);
							flag = true;
						}
					}
				}
				if(flag == false){
					//The output data does not depend on the input data.
					caseTrue = caseTrue + ", " + outputDataName;
				}
			}
			caseTrue = "\tTRUE:{" + caseTrue +"};";
			if(transitionList!=null && transitionList.size()>0) {
				for(String transition:transitionList) {
					nextOutPut = nextOutPut + "\t" + transition;
				}
			}
			nextOutPut = nextOutPut + caseTrue + "\r\nesac;";
		}
		//Generate the module of a process
		String inputText = "";
		if(inputList!=null && inputList.size()>0) {
			for(String input:inputList) {
				String input_s[] = input.split(" "); 
				inputText = inputText + input_s[0] + "_" + input_s[1] + "_input" + ", ";
			}
			inputText = inputText.substring(0,inputText.length() - 2);
		}
		module.add( "MODULE" + " " + moduleName + "(" + inputText + ")");
		String VAR_output = "";
		if(outputList!=null && outputList.size()>0) {
			VAR_output = "output : {";
			for(String output:outputList) {
				VAR_output = VAR_output + output + ", ";
			}
			VAR_output = VAR_output.substring(0,VAR_output.length() - 2) + ", None};";
			module.add("VAR");
			module.add(VAR_output);
			module.add("INIT");
			module.add("\toutput = None;");
		}
		if(outputList!=null && outputList.size()>0) {
			module.add("ASSIGN");
			module.add(nextOutPut);
		}
		return module;		
	}

	private static String getExternalSourceProcess(String data, String thisEntity, String externalEntityName,List<Entity> entityList) {
		// Get the external source process of the data flow.
		if(entityList!=null && entityList.size()>0) {
			Entity externalEntity = null;
			for(Entity entity:entityList) {
				if(entity.getEntityName().equals(externalEntityName)) {
					externalEntity = entity;
				}
			}
			if(externalEntity!=null) {
				List<Process> pList = externalEntity.getProcessList();
				if(pList!=null && pList.size()>0) {
					for(Process p:pList) {
						List<DataFlow> dataFlowOutList = p.getDataFlowOutList();
						if(dataFlowOutList!=null && dataFlowOutList.size()>0) {
							for(DataFlow d:dataFlowOutList) {
								List<Data> dataListInDataFlow = d.getData_transmission_config().getData();
								List<String> dataNamesInDataFlow = null;
								if(dataListInDataFlow!=null && dataListInDataFlow.size()>0) {
									dataNamesInDataFlow = new ArrayList<String>();
									for(Data dataInFlow:dataListInDataFlow) {
										dataNamesInDataFlow.add(dataInFlow.getDataName());
									}
								}
								if(dataNamesInDataFlow!=null && dataNamesInDataFlow.contains(data)) {
									//Find the data flow, return the external process name.
									return p.getName();
								}
							}
						}
					}
				}
			}
		}
		return null;
	}
}

	

