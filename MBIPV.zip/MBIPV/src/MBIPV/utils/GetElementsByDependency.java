package MBIPV.utils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;



public class GetElementsByDependency {
	public static List<Element> getElement(String id, String fileName) throws DocumentException{

    	   File xmlFile = new File(fileName);
    	   SAXReader sax = new SAXReader();
    	   Document document = sax.read(xmlFile);
    	   Element root = document.getRootElement();
    	   List<Element> elements = new ArrayList<Element>();
    	   elements = GetElementsByDependency.getNodes(id,root,elements,fileName);

       
   	return elements;
	}


public static List<Element> getNodes(String id, Element node, List<Element> elements, String fileName) {

	if(node.attributeValue("base_Dependency")!=null && node.attributeValue("base_Dependency").equals(id)) {
		elements.add(node);
		}

    List<Element> listElement = node.elements();
    for (Element e : listElement) {
    	elements = getNodes(id, e, elements, fileName);
  		}
	return  elements;   
	}	
}
