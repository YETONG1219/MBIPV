package MBIPV.utils;

import java.util.List;

public class Process  {
	private String name;
	private String entity; 
	private List<DataFlow> dataFlowInList; 
	private List<DataFlow> dataFlowOutList; 

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEntity() {
		return entity;
	}
	public void setEntity(String entity) {
		this.entity = entity;
	}
	public List<DataFlow> getDataFlowInList() {
		return dataFlowInList;
	}
	public void setDataFlowInList(List<DataFlow> dataFlowInList) {
		this.dataFlowInList = dataFlowInList;
	}
	public List<DataFlow> getDataFlowOutList() {
		return dataFlowOutList;
	}
	public void setDataFlowOutList(List<DataFlow> dataFlowOutList) {
		this.dataFlowOutList = dataFlowOutList;
	}	
}