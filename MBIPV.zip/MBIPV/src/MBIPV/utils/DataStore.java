package MBIPV.utils;

import java.util.List;

public class DataStore  {
	private String entity; 
	private String name; 
	private List<DataFlow> dataFlowInList; 
	private List<DataFlow> dataFlowOutList; 

	public String getEntity() {
		return entity;
	}
	public void setEntity(String entity) {
		this.entity = entity;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<DataFlow> getDataFlowInList() {
		return dataFlowInList;
	}
	public void setDataFlowInList(List<DataFlow> dataFlowInList) {
		this.dataFlowInList = dataFlowInList;
	}
	public List<DataFlow> getDataFlowOutList() {
		return dataFlowOutList;
	}
	public void setDataFlowOutList(List<DataFlow> dataFlowOutList) {
		this.dataFlowOutList = dataFlowOutList;
	}	
}