package MBIPV.utils;

import java.util.List;
import org.dom4j.Attribute;
import org.dom4j.DocumentException;
import org.dom4j.Element;




public class GetDataElementsByEnity {
	public static List<Data> getDataList(String id, Element node, List<Data> dataList, String fileName) throws DocumentException {
	    String entityName = node.attributeValue("name");
	    List<Element> listElement = node.elements();
	    for (Element e : listElement) {
			List<Attribute> attrList = e.attributes();
			if(attrList!=null && attrList.size()>0) {
				for(Attribute attribute:attrList) {
					if(attribute.getName().equals("type") && !attribute.getValue().equals("uml:Property")) {
						String dataElementID = attribute.getValue();
						Element dataElement = GetElementByID.getElement(dataElementID, fileName, "id");
						String dataName = dataElement.attributeValue("name");
						Element dataStereotype = GetElementByID.getElement(dataElementID, fileName, "base_Class");
						String isPrivacy = dataStereotype.attributeValue("isPrivacy");
						String fromEnternalEntity = dataStereotype.attributeValue("fromEnternalEntity");
						Data data = new Data();
						data.setDataName(dataName);
						data.setEntity(entityName);
						data.setIsPrivacy(isPrivacy);
						data.setFromExternalEntity(fromEnternalEntity);	
						dataList.add(data);
					}
				}
			}
	    }
	return dataList;   
	}	
}
