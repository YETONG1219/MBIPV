package MBIPV.formalModels;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import MBIPV.handlers.GetUMLModel;
import MBIPV.utils.Data;
import MBIPV.utils.DataFlow;
import MBIPV.utils.Entity;
import MBIPV.utils.EntityProcess;
import MBIPV.utils.Process;
import MBIPV.utils.UMLModel;




public class GenerateModelForV3 {
	//Generate the formal model to verify if V3 is violated.
	public static List<String> generateModel(UMLModel umlModel) throws IOException{
		List<String> model = new ArrayList<String>();
		//Get process list of entities.
		List<Entity> entityList = umlModel.getEntityList();
		List<Process> processList = new ArrayList<Process>();
		if(entityList!=null && entityList.size()>0) {
			for(Entity entity:entityList) {
				processList.addAll(entity.getProcessList());				
			}
		}
		//Generate process modules.
		List<String> externalDataAccessList = new ArrayList<String>();//The list of external data access of each entity.
		List<String> firstLineOfProcess = null;
		List<String> entityProcessHasOutput = new ArrayList<String>();//The list of EntityProcess that has output data to an external entity.
		if(processList!=null && processList.size()>0) {
			firstLineOfProcess = new ArrayList<String>();
			for(Process process:processList) {
				List<String> processModule = generateProcessModule(process, entityList, umlModel.getDataList(), externalDataAccessList, entityProcessHasOutput);
				firstLineOfProcess.add(processModule.get(0));//Save the first line of the module.
				model.addAll(processModule);//Add each process module.
			}
		}
		//Generate the data module of each entity.
		List<String> entityHasExternalPrivacyDataList = new ArrayList<String>();
		if(entityList!=null && entityList.size()>0) {
			for(Entity entity:entityList) {
				String entityDataModule = "";
				String externalPrivacyDataList = "";
				List<Data> externalDataList = entity.getExternalDataList();
				if(externalDataList!=null && externalDataList.size()>0) {
					for(Data data:externalDataList) {
						if(data.getIsPrivacy().equals("true")) {
							externalPrivacyDataList = externalPrivacyDataList + data.getDataName() + ", ";
							entityHasExternalPrivacyDataList.add(entity.getEntityName()+"Data");
						}
					}
					if(externalPrivacyDataList.contains(", ")) {
						externalPrivacyDataList = externalPrivacyDataList.substring(0,externalPrivacyDataList.length() - 2);
					}
					if(!externalPrivacyDataList.equals("")) {
						//More than one types of data.
						if(externalPrivacyDataList.contains(", ")) {
							entityDataModule = "MODULE " + entity.getEntityName() + "Data()\r\nVAR\r\n\texternalPrivacyData : {" + externalPrivacyDataList + "};"; 
							model.add(entityDataModule);
						}
						//Only one type of data. 
						else {
							entityDataModule = "MODULE " + entity.getEntityName() + "Data()\r\nDEFINE\r\n\texternalPrivacyData :=" + externalPrivacyDataList + ";"; 
							model.add(entityDataModule);						
						}	
					}
				}
			}
		}
		//Generate the main module.
		String mainModule = "MODULE main\r\nVAR\r\n";
		if(firstLineOfProcess!=null && firstLineOfProcess.size()>0) {
			for(String firstline:firstLineOfProcess) {
				String lineInMain = firstline.replace("MODULE ", "");
				String moduleName = lineInMain.split("\\(")[0];
				String processModule = lineInMain.split("\\(")[1].replace(")", "").replace("_input", ".output");
				mainModule = mainModule + "\t" + moduleName + " : " + moduleName + "(" + processModule + ");\r\n";
			}
			model.add(mainModule);
		}
		if(entityHasExternalPrivacyDataList!=null && entityHasExternalPrivacyDataList.size()>0) {
			for(String entityHasExternalPrivacyData:entityHasExternalPrivacyDataList) {
				if(!model.contains("\t" + entityHasExternalPrivacyData + " : " + entityHasExternalPrivacyData + "();"))
					model.add("\t" + entityHasExternalPrivacyData + " : " + entityHasExternalPrivacyData + "();");
			}
		}
		//Generate privacy properties for V3.
		if(externalDataAccessList!=null && externalDataAccessList.size()>0) {
			model.add("\r\n-----------------------Privacy Properties (V3)----------------------------");
			for(String externalDataAccess: externalDataAccessList) {
				String thisEntityProcess = externalDataAccess.split(" ")[0];
				String thisEntityDataModuleName = thisEntityProcess.split("_")[0] + "Data";
				if(entityHasExternalPrivacyDataList.contains(thisEntityDataModuleName)) {
					if(entityProcessHasOutput.contains(thisEntityProcess)) {
						String privacyProperty = "CTLSPEC !EF(" + thisEntityProcess + ".output = " + thisEntityDataModuleName + ".externalPrivacyData);--/*For V3*/";
						if(!model.contains(privacyProperty))
							model.add(privacyProperty);						
					}
				}
			}
		}
		return model;
	}
	private static List<String> generateProcessModule(Process process, List<Entity> entityList, List<Data> dataList, List<String> externalDataAccessList, List<String> entityProcessHasOutput) {
		// Generate the module of the process.
		List<String> module = new ArrayList<String>();
		String thisEntity = process.getEntity();
		String thisProcess = process.getName();
		String moduleName = thisEntity + "_" + thisProcess;

		//Get the input list.
		List<String> inputList = null;//It saves the list of inputData,sourceEntity and sourceProcess. 
		List<DataFlow> dataFlowInList = process.getDataFlowInList();
		if(dataFlowInList!=null && dataFlowInList.size()>0) {
			inputList = new ArrayList<String>();
			for(DataFlow dataFlow: dataFlowInList) {
				EntityProcess dataFlowSource = dataFlow.getSource_entity_process();
				String sourceEntity = dataFlowSource.getEntity();
				String sourceProcess = dataFlowSource.getProcess();
				List<Data> dataInFLowList = dataFlow.getData_transmission_config().getData();
				List<String> dataNameList = null;
				if(dataInFLowList!=null && dataInFLowList.size()>0) {
					dataNameList = new ArrayList<String>();
					for(Data data: dataInFLowList) {
						dataNameList.add(data.getDataName());
					}
				}
				if(sourceProcess.equals("")) {
					//Data flows from an external entity.
					String externalEntity = sourceEntity;
					if(dataNameList!=null && dataNameList.size()>0) {
						for(String data:dataNameList) {
							String externalSourceProcess = getExternalSourceProcess(data,thisEntity,externalEntity,entityList);
							String input = externalEntity + " " + externalSourceProcess + " " + data;
							inputList.add(input);
							//Add the data to the list of external data access of each entity.
							externalDataAccessList.add(thisEntity + "_" + thisProcess + " " + externalEntity + "_" + externalSourceProcess + " " + data);
						}
					}
				}
				else {
					//Data flows from a process in this entity.
					for(String data:dataNameList) {
						String input = thisEntity + " " + sourceProcess + " " + data;
						inputList.add(input);
					}
				}			
			}
		}
		//Get the output list.
		List<String> outputList = null;//It saves the list of outputData,sourceEntity and sourceProcess. 
		List<DataFlow> dataFlowOutList = process.getDataFlowOutList();
		if(dataFlowOutList!=null && dataFlowOutList.size()>0) {
			entityProcessHasOutput.add(thisEntity + "_" + thisProcess);
			outputList = new ArrayList<String>();
			for(DataFlow dataFlow:dataFlowOutList) {
				List<Data> dataOutList = dataFlow.getData_transmission_config().getData();
				if(dataOutList!=null && dataOutList.size()>0) {
					for(Data dataOut: dataOutList) {
						if(!outputList.contains(dataOut.getDataName()))
							outputList.add(dataOut.getDataName());
					}
				}
			}
		}
		//Generate the transitions of output data.
		List<String> transitionList = new ArrayList<String>();
		String nextOutPut = "";
		String caseTrue = "None";
		if(outputList!=null && outputList.size()>0) {
			nextOutPut = "next(output):=case\r\n";
			for(String outputDataName: outputList) {
				Data data = GetUMLModel.getDataByNameFromDataList(thisEntity, outputDataName, dataList);
				String dependsOnData = data.getDependsOnData();
				System.out.println("dataName:" + data.getDataName() + " " + "dependsOnData:" + dependsOnData);
				boolean flag = false;
				if(inputList!=null && inputList.size()>0) {
					//Generate the "case" of the transition.
					for(String in:inputList) {
						String ins[]= in.split(" ");
						//Get the source entity, source process and data name of each input data.
						String sourceEntity = ins[0];
						String sourceProcess = ins[1];
						String dataNameInInputList = ins[2];
						if(dependsOnData.equals(dataNameInInputList)) {
							//The output data depends on the input data.
							String input = sourceEntity + "_" + sourceProcess + "_input = " + dependsOnData;
							String transition = "(" + input + ")" + ":" + outputDataName + ";\r\n";
							transitionList.add(transition);
							flag = true;
						}
						if (dataNameInInputList.equals(outputDataName)) {
							//The output data depends on the input data.
							String input = sourceEntity + "_" + sourceProcess + "_input = " + outputDataName;
							String transition = "(" + input + ")" + ":" + outputDataName + ";\r\n";
							transitionList.add(transition);
							flag = true;
						}
					}
				}
				if(flag == false) {
					//The output data does not depend on the input data.
					caseTrue = caseTrue + ", " + outputDataName;
				}
			}
			caseTrue = "\tTRUE:{" + caseTrue +"};";
			if(transitionList!=null && transitionList.size()>0) {
				for(String transition:transitionList) {
					nextOutPut = nextOutPut + "\t" + transition;
				}
			}
			nextOutPut = nextOutPut + caseTrue + "\r\nesac;";
		}
		//Generate the module of a process
		String inputText = "";
		if(inputList!=null && inputList.size()>0) {
			for(String input:inputList) {
				String input_s[] = input.split(" "); 
				inputText = inputText + input_s[0] + "_" + input_s[1] + "_input" + ", ";
			}
			inputText = inputText.substring(0,inputText.length() - 2);
		}
		module.add( "MODULE" + " " + moduleName + "(" + inputText + ")");
		String VAR_output = "";
		if(outputList!=null && outputList.size()>0) {
			VAR_output = "output : {";
			for(String output:outputList) {
				VAR_output = VAR_output + output + ", ";
			}
			VAR_output = VAR_output.substring(0,VAR_output.length() - 2) + ", None};";
			module.add("VAR");
			module.add(VAR_output);
			module.add("INIT");
			module.add("\toutput = None;");
		}
		if(outputList!=null && outputList.size()>0) {
			module.add("ASSIGN");
			module.add(nextOutPut);
		}
		return module;		
	}
	private static String getExternalSourceProcess(String data, String thisEntity, String externalEntityName,List<Entity> entityList) {
		// Get the external source process of the data flow.
		if(entityList!=null && entityList.size()>0) {
			Entity externalEntity = null;
			for(Entity entity:entityList) {
				if(entity.getEntityName().equals(externalEntityName)) {
					externalEntity = entity;
				}
			}
			if(externalEntity!=null) {
				List<Process> pList = externalEntity.getProcessList();
				if(pList!=null && pList.size()>0) {
					for(Process p:pList) {
						List<DataFlow> dataFlowOutList = p.getDataFlowOutList();
						if(dataFlowOutList!=null && dataFlowOutList.size()>0) {
							for(DataFlow d:dataFlowOutList) {
								List<Data> dataListInDataFlow = d.getData_transmission_config().getData();
								List<String> dataNamesInDataFlow = null;
								if(dataListInDataFlow!=null && dataListInDataFlow.size()>0) {
									dataNamesInDataFlow = new ArrayList<String>();
									for(Data dataInFlow:dataListInDataFlow) {
										dataNamesInDataFlow.add(dataInFlow.getDataName());
									}
								}
								if(dataNamesInDataFlow!=null && dataNamesInDataFlow.contains(data)) {
									//Find the data flow, return the external process name.
									return p.getName();
								}
							}
						}
					}
				}
			}
		}
		return null;
	}
}
	

