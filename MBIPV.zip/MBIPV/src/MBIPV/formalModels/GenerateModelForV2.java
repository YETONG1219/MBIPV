package MBIPV.formalModels;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import MBIPV.utils.DataAccess;
import MBIPV.utils.UMLModel;


public class GenerateModelForV2 {
	//Generate the formal model to verify if V2 is violated.
	public static List<String> generateModel(UMLModel umlModel) throws IOException{
		List<String> model = new ArrayList<String>();
		//Get the dataAccess model and generate the permission module for each entity
		List<DataAccess> dataAccessList = umlModel.getDataAccessList();
		List<String> entityGrantPermission = new ArrayList<String>();
		List<DataAccess> dataGrantList = new ArrayList<DataAccess>();
		List<DataAccess> dataRequestList = new ArrayList<DataAccess>();
		List<DataAccess> dataRevokeList = new ArrayList<DataAccess>();
		List<String> allEntitiesGrantList = new ArrayList<String>();
		List<String> mainModule = new ArrayList<String>();
		if(dataAccessList!=null && dataAccessList.size()>0) {
			for(DataAccess dataAccess:dataAccessList) {
				if(dataAccess.getType().equals("grants")) {
					dataGrantList.add(dataAccess);
					String entity = dataAccess.getEntityProcess().getEntity();
					if(!entityGrantPermission.contains(entity)) {
						entityGrantPermission.add(entity);
					}
				}
				if(dataAccess.getType().equals("requests")) {
					dataRequestList.add(dataAccess);
				}
				if(dataAccess.getType().equals("revokes")) {
					dataRevokeList.add(dataAccess);
				}
			}
		}
		if(entityGrantPermission!=null && entityGrantPermission.size()>0) {
			mainModule.add("MODULE main");
			mainModule.add("VAR");
			for(String entity:entityGrantPermission) {
				List<String> grantListText = new ArrayList<String>();
				List<String> permissionModule = generatePermissionModule(entity, dataGrantList, dataRevokeList, dataRequestList, grantListText);
				model.addAll(permissionModule);//Add each permission module.
				allEntitiesGrantList.addAll(grantListText);
				mainModule.add("\t" + entity + "_Permission : " + entity + "_Permission();");//Generate the main module.

			}
			model.addAll(mainModule);
		}
		//Generate privacy properties for V2.
		List<String> propertyList  = null;
		if(allEntitiesGrantList!=null && allEntitiesGrantList.size()>0) {
			propertyList = new ArrayList<String>();
			propertyList.add("-----------------------Privacy Properties (V2)----------------------------");
			for(String grant: allEntitiesGrantList) {
				String sourceEntity = grant.split(" ")[0];
				String targetEntityProcess = grant.split(" ")[1];
				String data = grant.split(" ")[2];
				String privacyProperty = "CTLSPEC !EF(" + sourceEntity + "_Permission.GrantAccessTo_" + targetEntityProcess +"_"+ data + " = TRUE" + 
										" & " + sourceEntity + "_Permission.RevokeAccessTo_" + targetEntityProcess +"_"+ data + " = FALSE);--/*For V2*/";
				if(!propertyList.contains(privacyProperty))
					propertyList.add(privacyProperty);
			}
			model.addAll(propertyList);
		}
		return model;
	}
	private static List<String> generatePermissionModule(String entity, List<DataAccess> dataGrantList,List<DataAccess> dataRevokeList, List<DataAccess> dataRequestList, List<String> grantListText) {
		// Generate the permission module of each entity in the list of entityGrantPermission.
		List<String> entityPermissionModule = null;
		List<String> grantList = new ArrayList<String>();
		List<String> revokeList = new ArrayList<String>();
		
		if(dataGrantList!=null && dataGrantList.size()>0) {
			entityPermissionModule = new ArrayList<String>();
			entityPermissionModule.add("MODULE " + entity + "_Permission()");
			entityPermissionModule.add("DEFINE");
			for(DataAccess dataAccessGrant:dataGrantList) {
				if(dataAccessGrant.getEntityProcess().getEntity().equals(entity)) {
					String data = dataAccessGrant.getData();
					if(data != "" && dataRequestList !=null && dataRequestList.size()>0) {
						for(DataAccess dataAccessRequest:dataRequestList) {
							String requestData = dataAccessRequest.getData();
							if(data.equals(requestData)) {
								String requestEntity = dataAccessRequest.getEntityProcess().getEntity();
								String requestProcess = dataAccessRequest.getEntityProcess().getProcess();
								String defineText = "\t GrantAccessTo_" + requestEntity + "_" + requestProcess + "_" + data + " := TRUE;";
								if(!grantList.contains(defineText)){
									grantList.add(defineText);
									grantListText.add(entity + " " + requestEntity + "_" + requestProcess + " " + data);
								}
							}
						}
					}
				}
			}
		}
		if(dataRevokeList!=null && dataRevokeList.size()>0) {
			if(entityPermissionModule != null) {
				for(DataAccess dataAccessRevoke:dataRevokeList) {
					if(dataAccessRevoke.getEntityProcess().getEntity().equals(entity)) {
						String data = dataAccessRevoke.getData();
						if(data != "" && dataRequestList !=null && dataRequestList.size()>0) {
							for(DataAccess dataAccessRequest:dataRequestList) {
								String requestData = dataAccessRequest.getData();
								if(data.equals(requestData)) {
									String requestEntity = dataAccessRequest.getEntityProcess().getEntity();
									String requestProcess = dataAccessRequest.getEntityProcess().getProcess();
									String defineText = "\t RevokeAccessTo_" + requestEntity + "_" + requestProcess + "_" + data + " := TRUE;";
									if(!revokeList.contains(defineText))
										revokeList.add(defineText);
								}
							}
						}
					}
				}
			}
		}
		if(grantList!=null && grantList.size()>0) {
			for(String grant:grantList) {
				String correspondingRevokeText = grant.replace("GrantAccessTo", "RevokeAccessTo");
				if(!revokeList.contains(correspondingRevokeText)) {
					revokeList.add(correspondingRevokeText.replace(" := TRUE;", " := FALSE;"));
				}
			}
		}
		//Add the grant list and the revoke list to the permission module of the entity.
		if(grantList!=null && grantList.size()>0) {
			entityPermissionModule.addAll(grantList);
		}
		if(revokeList!=null && revokeList.size()>0) {
			entityPermissionModule.addAll(revokeList);
		}		
		return entityPermissionModule;
	}
}
	

